-- Casting of date and taking only required columns from transformation dataset to Final dataset
BEGIN

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.Delta_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Delta_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.FDR_PSCU_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.FDR_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.WF_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.pnc_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.fsv_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.rbc_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.scotia_Merchandise_Gift`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.FDR_Apple`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.rbc_Apple`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.scotia_Apple`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.WF_Apple`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.ua_Apple`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.ua_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.pnc_Apple`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.bac_Travel`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,DB_Visits_Web_conversion as visits_with_conversions_by_agents,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,DB_Visits_Web_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.FDR_PSCU_Travel`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,DB_Visits_Web_conversion as visits_with_conversions_by_agents,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,DB_Visits_Web_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.FDR_Travel`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,DB_Visits_Web_conversion as visits_with_conversions_by_agents,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,DB_Visits_Web_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.WF_Travel`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,DB_Visits_Web_conversion as visits_with_conversions_by_agents,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,DB_Visits_Web_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.pnc_Travel`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,DB_Visits_Web_conversion as visits_with_conversions_by_agents,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,DB_Visits_Web_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.psg_Travel`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,DB_Visits_Web_conversion as visits_with_conversions_by_agents,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,DB_Visits_Web_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.fsv_Travel`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,DB_Visits_Web_conversion as visits_with_conversions_by_agents,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,DB_Visits_Web_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.fsv_EventTickets`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_EventTickets`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.FDR_PSCU_CustomStore`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_CustomStore`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.FDR_CustomStore`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_CustomStore`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.fsv_CustomStore`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_CustomStore`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Final_Dataset}}.Chase`
AS SELECT CAST(Date AS DATE) AS Date, Unique_visitors, Visits, Actions,db_visits_conversion as Visits_with_Conversions,db_conversion_rate as Conversion_Rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,db_visits_conversion,db_conversion_rate FROM `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Chase`);

END