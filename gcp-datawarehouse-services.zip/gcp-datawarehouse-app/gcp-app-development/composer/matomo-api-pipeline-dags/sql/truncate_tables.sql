-- Truncating all the tables in Staging Dataset
BEGIN 

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.Delta_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_PSCU_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.WF_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.pnc_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.rbc_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.scotia_Merchandise_Gift`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_Apple`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.rbc_Apple`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.scotia_Apple`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.WF_Apple`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.ua_Apple`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.pnc_Apple`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.bac_Travel`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_PSCU_Travel`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_Travel`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.WF_Travel`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.pnc_Travel`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.psg_Travel`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_Travel`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_EventTickets`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_PSCU_CustomStore`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_CustomStore`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_CustomStore`;

TRUNCATE TABLE          `{{params.Project_Name}}.{{params.Staging_Dataset}}.Chase`;

END