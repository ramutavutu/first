from google.cloud import bigquery

def load_csv_to_bq(event, context):
    # GCS details
    bucket_name = "gcs-to-bq-testing"
    file_name = "GCS_to_BQ_sample.csv"
    
    # BQ details
    project_id = "bkt-nonprod-dev-dwh-svc-00"
    dataset_name = "bq_dataload_testing"
    table_name = "gcs_to_bq_load"
    
    # Initialize BigQuery client
    bq_client = bigquery.Client(project=project_id)
    
    # Create dataset reference
    dataset_ref = bq_client.dataset(dataset_name)
    
    # Create table reference
    table_ref = dataset_ref.table(table_name)
    
    # Load job configuration
    job_config = bigquery.LoadJobConfig()
    job_config.source_format = bigquery.SourceFormat.CSV
    job_config.skip_leading_rows = 1  # Skip the header row
    job_config.autodetect = True  # Auto-detect schema
    
    # Load data from GCS to BQ
    uri = f"gs://{bucket_name}/{file_name}"
    load_job = bq_client.load_table_from_uri(uri, table_ref, job_config=job_config)
    
    load_job.result()  # Wait for the job to complete
    
    print(f"Data loaded from {uri} to {project_id}.{dataset_name}.{table_name}")

# You might not need this if you're deploying the code as a Cloud Function
if __name__ == "__main__":
    load_csv_to_bq(None, None)
