from atlassian import Jira
from google.cloud import storage
import pandas as pd
import json
from pandas import json_normalize
import csv
from io import StringIO
from datetime import datetime
import os
import requests
#import gcsfs
from google.cloud import bigquery
import time
import numpy as np
from requests.exceptions import HTTPError

def get_project_statuses_write_to_gcs():
  JIRA_CLOUD_BASE_URL = "https://peak6-technologies.atlassian.net"
  JIRA_CLOUD_URL = JIRA_CLOUD_BASE_URL + "/issues/?filter=10227"
  #JIRA_USER_NAME = "kothandaraman.sikamani@bakkt.com"
  #JIRA_CLOUD_TOKEN = "JzvAAudNf6uGus45kbybBE76"

  #JIRA_USER_NAME = "nithin.kallem@bakkt.com"
  #JIRA_CLOUD_TOKEN = "ATATT3xFfGF0tE85NomzBGcGHuKS11S8Xdqfmi8EAiPPMnU1iiPQL3MMqUVHcWlsbsK3Y0gbZNuJ3gz-Cm2m8m-gThcU1ro3cxBfKJ0M-fDDZT3kt53DMDAfymdUffb8V9TToW_WIVhZa-HZLJ1vFpvyV0OHQfJFfjMv0n61xQl2HqW64xSBW5E=EBA3097D"

  #JIRA_USER_NAME = "kothandaraman.sikamani@bakkt.com"
  #JIRA_CLOUD_TOKEN = "JzvAAudNf6uGus45kbybBE76"

  JIRA_USER_NAME = "bhushanahire.sahebrao@bakkt.com"
  JIRA_CLOUD_TOKEN = "ATATT3xFfGF0LsiG34gfp25Rg7mNKWeTtdClyaDZg5NKWPlfaKThBY8RS4qkS1JN_7lIG06W5_DmigHPmxfw2XvFx3yafRd2hsynr03_pMpgY11-Bqg4B5VM6kP7_aOQk-sKaDEdvzzlIW-4PVAT52tceDcnju4_9PdEKMGTuFwNlbSrxWlj5Mg=42E6651B"

  jira_instance = Jira(
      url = JIRA_CLOUD_BASE_URL,
      username = JIRA_USER_NAME,
      password = JIRA_CLOUD_TOKEN,
      cloud=True)
  
  jql_request = 'project in ("BKT","BAK")'
  
  #jql_response = jira_instance.jql(jql_request)
  FIELDS_OF_INTEREST = ['id','key','type','status','created',"issuetype", "status", "summary",'customfield_10153','customfield_10010','updated','customfield_10018','customfield_10184','customfield_10080','customfield_10142','customfield_10044','customfield_10172','customfield_10232','customfield_10160','customfield_10001','customfield_10168','customfield_10169','customfield_10257','Intake Meeting', 'customfield_10185']
       
  start_at = 0
  end_of_stream = False
  project_statuses = pd.DataFrame()

  print('Called get_project_statuses() ... ') 
  
  while (not end_of_stream):
    jql_response = jira_instance.jql(jql_request, limit = 10000, start = start_at, fields=FIELDS_OF_INTEREST)
    jql_response
    if jql_response['issues'] == []:
      end_of_stream = True
    else:
      df_in = pd.json_normalize(jql_response["issues"])
      #df_in = pd.json_normalize(jql_response) 
      df_in.head()

      start_at = jql_response['startAt'] + jql_response['maxResults']
      total_issues = jql_response['total']
      end_of_stream = False
      time.sleep(0.2)

      print(start_at)
      print(end_of_stream)
      print(jql_response['maxResults'])
      project_statuses = pd.concat([project_statuses,df_in])


  print('Final Total AS Fetched :', len(project_statuses))
  print(project_statuses.columns)
  # getting the current date and time
  current_datetime = datetime.now()
  current_date_time = current_datetime.strftime("%m-%d-%Y")
  print("current date and time = ",current_date_time)

  gcs_bucket_name = "bkt-nonprod-dev-dwh-svc-00-jira-issues-statuses"
  gcs_bucket_name 
  gcs_filepath = 'gs://{}/custom_project_statuses_bak'.format(gcs_bucket_name)

  gcs_filepath = gcs_filepath +"-"+ str(current_date_time) + ".csv"
  print(gcs_filepath)
  #df.columns = df.columns.str.replace('.', '_')

  project_statuses = project_statuses.drop('expand', axis=1)
  project_statuses = project_statuses.drop('id', axis=1)  
  project_statuses = project_statuses.drop('self', axis=1)
  project_statuses = project_statuses.drop('fields.issuetype.self', axis=1)  
  project_statuses = project_statuses.drop('fields.issuetype.id', axis=1)
  project_statuses = project_statuses.drop('fields.issuetype.description', axis=1)  
  project_statuses = project_statuses.drop('fields.issuetype.iconUrl', axis=1)
  project_statuses = project_statuses.drop('fields.issuetype.subtask', axis=1)  
  project_statuses = project_statuses.drop('fields.issuetype.avatarId', axis=1)  
  project_statuses = project_statuses.drop('fields.issuetype.hierarchyLevel', axis=1)
  project_statuses = project_statuses.drop('fields.status.description', axis=1)  
  project_statuses = project_statuses.drop('fields.status.iconUrl', axis=1)
  project_statuses = project_statuses.drop('fields.status.id', axis=1)  

  project_statuses.to_csv(gcs_filepath)

  return project_statuses  

def hello_http(request):
  df = get_project_statuses_write_to_gcs()
  df.head(3)
  return {'response' : 'Success'}



