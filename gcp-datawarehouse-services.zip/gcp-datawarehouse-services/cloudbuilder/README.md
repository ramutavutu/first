# Setting up CloudBiuld Terraform Docker Image
### The purpose of this module is to deploy a reusable docker template and pack as a docker image. Cloudbuild will call this image when running Terraform commands.

### Prerequisite:
*  **The user running the modules must have the following IAM roles in the Devops Project**
    - Artifact Registry Admin
    - Storage Admin
    - Cloud Build Editor
    - Service Usage Consumer
    - Viewer role to view the build log process in the cloudshell
    - Compute Network User role in the Host network project

*  **Ensure the following API are enabled in the Devops project**
    - Cloud Build API
    - Compute Engine API
    - Artifact Registry API

    - Create 3 Artifact bucket in the [Artifact Registry](https://console.cloud.google.com/artifacts?referrer=search&project=bkt-common-devops-00) for Dev, Partner and Prod docker image.

### Follow the next step once prerequisite has been met
*  **Lunch google cloud shell and set the project**
    - Follow this steps when running from a local terminal to authenticate and setup a google project by using gcloud command
```
    gcloud auth login (follow the token link the sign into the google cloud account)
```
```
    gcloud config set project DEVOPS_PROJECT_ID
```
- Follow this step when using Google Cloud Shell
- Lunch the Cloudshell and run the gcloud command to set the Devops project ID
```
    gcloud config set project DEVOPS_PROJECT_ID

```

- Upload or move the CloudBuild folder to the working directory and cd into the folder in terminal

*   **📁 ${cloudbuilder}**
     *   **cloudbuild.yaml**
     *   **Dockerfile**
     *   **entrypoint.bash**
     *   **README.md**

*  **Provide the Required values to the variables used in the gcloud command**
    - _REGION                         =us-east1 (Allocated region)
    - _PROJECT_ID                     =bkt-common-devops-00 (devops project id to store the artifacts) [artifact gcs location after build](https://console.cloud.google.com/storage/browser?project=bkt-common-devops-00&prefix=)
    - _REPOSITORY                     =nonprod-dwh-dev [Artifact bucket name created for the build](https://console.cloud.google.com/artifacts?referrer=search&project=bkt-common-devops-00)
    - _TERRAFORM_VERSION              =1.2.9 (Terraform Version)
    - _TERRAFORM_VERSION_SHA256SUM    =0e0fc38641addac17103122e1953a9afad764a90e74daf4ff8ceeba4e362f2fb (Terraform Version Checksum)
    - _TERRAFORM_VALIDATOR_RELEASE    =2021-03-22 (Terraform Version release date)

*  **Run the following gcloud commands with the attributes above inserted based on the environment. Update the Artifact repository name to match the artifact bucket when building for a different environment.**
```      
gcloud auth configure-docker \ us-east1-docker.pkg.dev
```
```
gcloud builds submit . --config cloudbuild.yaml --substitutions _REGION=us-east1,_PROJECT_ID=bkt-common-devops-00,_REPOSITORY=nonprod-dwh-dev,_TERRAFORM_VERSION=1.2.9,_TERRAFORM_VERSION_SHA256SUM=0e0fc38641addac17103122e1953a9afad764a90e74daf4ff8ceeba4e362f2fb,_TERRAFORM_VALIDATOR_RELEASE=2021-03-22
```

### The gcloud build command can be run 3 times to bbuild the dev, Partner and Prod image. Note: the Artifact bucket has to be updated to match the environment.

### Follow this steps if a new version of Terraform is needed in the future. Another image version can be created after making the following changes.
*  **cloudbuild.yaml**
    - Updates line 21 & 27 by adding tags after terraform. eg. /terraform-v2
    - Update line 30 - 32 with the updated terraform versions, checksum and release date

*  **Dockerfile**
        - Update line 18 - 20 with the updated terraform versions, checksum and release version

### Update and run the gcloud command once the above changes has been made to match the new attributes
        - gcloud builds submit . --config cloudbuild.yaml --substitutions _REGION=us-east1,_PROJECT_ID=bkt-common-devops-00,_REPOSITORY=nonprod-dwh-dev,_TERRAFORM_VERSION=1.2.9,_TERRAFORM_VERSION_SHA256SUM=0e0fc38641addac17103122e1953a9afad764a90e74daf4ff8ceeba4e362f2fb,_TERRAFORM_VALIDATOR_RELEASE=2021-03-22

### We can now setup a cloudbuild trigger once the docker images has been pushed to Artifact Registry




## Cloudbuild Triggers configuration to run the Terraform modules
### Prerequisite:
*  **Enabled the required API needed for the services in all the projects (Host Network, Datawarehouse, and Devops Project)**
    - Cloud Resource Manager API
    - Compute Engine API
    - Cloud Pub/Sub API
    - Identity and Access Management (IAM) API
    - Dataflow API
    - Artifact Registry API
    - Secret Manager API
    - BigQuery API
    - Cloud DNS API
    - Cloud Build API
    - Kubernetes Engine API
    - Service Networking API
    - IAM Service Account Credentials API
    - Datastream API

*  **The Devops Service Account running this module from cloudbuild must have the initial IAM Roles**
    - Cloud Build Editor (Devops Project)
    - Project IAM Admin (Datawarehouse Project)
    - Storage Object Admin (Devops project. Needed to access Cloudbuilder Artifacts in GCS)
    - Artifact Registry Writer (Devops Project. Required)
    - Logs Writer (Devops Project. Needed to write build logs)
    - Service Account Admin (Dwh project. Needed to create a service account via terraform)
    - Service Account User (Dwh project. Needed to use resources service accounts)
    - Compute Network User (Host Network Project)

### We can now proceed setting up a cloud build trigger once the initial IAM has been assigned.
### Notes: Additional IAM roles will be assigned to the Devops service account from the terraform code based on the resources we are deploying and set a dependencies to avoid race conditions.

*  **Connect the cloudcuild to the github repository. Note: Ensure that the User performing this roles have the required permission to perform the operation on the repo**
    - Navigate to Cloudbuild in Devops project
    - Click on Trigger
    - Click connect Repository and follow the steps to authenticate to the github

*  **Steps to create CloudBuild triggers by making use of the Artifact docker image. Note: Use appropriate Image for the right environment (Dev image for the development environment etc.) This will be usefull when and image needs to be updated by trying in a lower environment first before promoting to higher environments.**

*  **Now create a cloudbuild pull and push triggers for jobs. Note: Add an approval to the push trigger to require addition later of approval after github merge from feature branch to main branch**
```
    - Provide the trigger name
    - Tag e.g (dwh-dev)
    - Sellect pull or push request depending on the trigger being created
    - Select the Application Repo and set the base branch to main or master ^(main)$
    - Expand the INCLUDED and IGNORED dropped down.
        - Included Files: Add the path of the directory for the cloudbuild to keep track of any changes. Cloud build will be triggered if their is any changes in the directory added. A folder name can be provided ending with /** to keep track of all the files in the folder. eg gcp-app-development/composer/matomo-api-pipeline/** to keep track of all the files in the matomo-api-pipeline folser or gcp-app-development/composer/matomo-api-pipeline/config.py which will only keep track of the config.py file in the directory. Cloudbuild will ignore any changes made to the other files in the directory or folder.
        - Ignored Files: Exeptional. Cloudbuild will stricktly ignore any changes made to the ignore file and no job will run

    - Select CLoud Build as the configuration file
    - Provide the path to the cloudbuild pull or push request yaml file that will run Terraform init, validate, plan and apply. eg pipelines/gcp-dev-matomo-pull-request.yaml
    - Under advanced, Provide the substitute variables. All the variables has been used inside the gcp-dev-matomo-pull-request.yaml  file and a value will be provided.

        - _ARTIFACT_BUCKET_NAME  :  - This is the GCS artifact location of the cloud builder. All the cloudbuild jobs will be pushed to the bucket
        - _DEFAULT_REGION        :  - Environment region
        - _DEVOPS_PROJECT_ID     :  - Devops project ID
        - _ENV                   : dev
        - _GAR_REPOSITORY        :  - CloudBuilder Terraform Artifact to use for the terraform build that resides in the Devops project Artifact Registry. [Artifact Registry](https://console.cloud.google.com/artifacts?referrer=search&project=bkt-common-devops-00)
        - _TF_ACTION             : plan  - Terraform action (plan or appy)
        - _WORKSTREAM_NAME       : dwh-dev
        - __WORKSTREAM_PATH      : pipelines/terraform/dev  - workstream path of the terraform directory location to apply TF commands.

    - Mark the require and approval for the push triggers to enforce additional approval before deployment

    - Select the appropriate Devops service account to run the Job
```

## The user approving the cloudbuild triggers must have the following roles
        - Cloud Build Approval
        - Cloud Build Viewer