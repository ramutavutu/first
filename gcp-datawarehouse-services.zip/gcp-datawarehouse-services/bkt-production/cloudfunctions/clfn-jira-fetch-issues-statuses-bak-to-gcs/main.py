from requests.auth import HTTPBasicAuth
import json
import pandas as pd
import csv
from io import StringIO
from datetime import datetime
from google.cloud import storage
import os
import requests
#import gcsfs
from google.cloud import bigquery

import time
import numpy as np
import re
import requests
from requests.exceptions import HTTPError

##https://sherwoodforest.atlassian.net/rest/api/3/search?jql=project=PRJ&fields=id,key,type,status,created,customfield_10153,customfield_10010,updated,customfield_10018,customfield_10184

JIRA_CLOUD_BASE_URL = "https://sherwoodforest.atlassian.net"
#JIRA_USER_NAME = "nithin.kallem@bakkt.com"
#JIRA_CLOUD_TOKEN = "ATATT3xFfGF0tE85NomzBGcGHuKS11S8Xdqfmi8EAiPPMnU1iiPQL3MMqUVHcWlsbsK3Y0gbZNuJ3gz-Cm2m8m-gThcU1ro3cxBfKJ0M-fDDZT3kt53DMDAfymdUffb8V9TToW_WIVhZa-HZLJ1vFpvyV0OHQfJFfjMv0n61xQl2HqW64xSBW5E=EBA3097D"

#JIRA_USER_NAME = "kothandaraman.sikamani@bakkt.com"
#JIRA_CLOUD_TOKEN = "JzvAAudNf6uGus45kbybBE76"

JIRA_USER_NAME = "bhushanahire.sahebrao@bakkt.com"
JIRA_CLOUD_TOKEN = "ATATT3xFfGF0LsiG34gfp25Rg7mNKWeTtdClyaDZg5NKWPlfaKThBY8RS4qkS1JN_7lIG06W5_DmigHPmxfw2XvFx3yafRd2hsynr03_pMpgY11-Bqg4B5VM6kP7_aOQk-sKaDEdvzzlIW-4PVAT52tceDcnju4_9PdEKMGTuFwNlbSrxWlj5Mg=42E6651B"

#JIRA_USER_NAME = "ramu.tavutu@bakkt.com"
#JIRA_CLOUD_TOKEN = "ATATT3xFfGF0viKEyECznhf3j9yosIcn2yHM-x6CYy2NPBdoxCAVASs7MTVdDvPF9sFTXFiQhrGIEEXqT9immlEwdfOs_kD1iRJlLjEzal2VtHdl0XSFk_LnQKP3mMJ68PSAUdSKqGCDGuWRxVsFJby7l4wD24mstf6mQAUAik6-NsvMo6CTUDk=AB09CCA4"



def get_statuses_write_to_gcs():
  start_at = 0
  end_of_stream = False
  issue_lst = []
  retries = 0

  print('Called get_issues() ... ') 
  
  while (not end_of_stream) and (retries < 4):

    url = JIRA_CLOUD_BASE_URL + "/rest/api/3/search?" 
    headers={
      "Accept": "application/json",
      "Content-Type": "application/json"
    }

    auth = HTTPBasicAuth(JIRA_USER_NAME, JIRA_CLOUD_TOKEN)

    #project = PRJ ORDER BY key ASC
    query = {
      'jql': 'project in ("BKT","BAK")',
      'maxResults' : 100,
      'expand': 'changelog',
      'fields': 'id,key,type,status,created,customfield_10153,customfield_10010,updated,customfield_10018,customfield_10184',
      'startAt' : {start_at}
    }

    response = requests.request(
      "GET",
      url,
      headers=headers,
      params=query,
      auth=auth
    )

    print(start_at)   
    print(url) 
    print(response)   
    
    if response.status_code == 429: #rate limit hit
      print("Rate limited. Waiting 60 seconds...")
      retries += 1
      time.sleep(60)

    elif response.status_code == 401: #unauthorized:
      print("Unathorized. Please update credentials")
      end_of_stream = True

    elif response.status_code == 403: #forbidden:
      print("Forbidden")
      end_of_stream = True

    elif response.status_code == 200:
      if response.json()['issues'] == []:
        end_of_stream = True
      else:
        issue_lst.extend(response.json()['issues'])
        start_at = response.json()['startAt'] + response.json()['maxResults']
        total_issues = response.json()['total'] 
        end_of_stream = False
        time.sleep(0.2)
        print(start_at)
        print(end_of_stream)
        print(response.json()['maxResults'])
    else:
      raise Exception(f"Error code {response.status_code}: {response.json()}")
      end_of_stream = True

  #Create a Pandas DataFrame
  df = pd.json_normalize(issue_lst) 
  df.head()
  print(df.columns)

  #'id','key','type','status','created','customfield_10153','customfield_10010','updated','customfield_10018','customfield_10184'
  # Get the base data

  base = pd.json_normalize(issue_lst)[['key', 'fields.created']]
  base.rename(columns={'fields.created': 'created'}, inplace=True)
  # Get the transitions
  transitions = pd.json_normalize(data=issue_lst,
                                  record_path=['changelog', 'histories'],
                                  meta=['fields', 'key'])[['created', 'items', 'key']]
  # Filter and transform the status transitions
  transitions = transitions\
      .join(transitions['items']\
              .explode()
              .apply(pd.Series)
      )\
      .query("field == 'status'")\
      .drop("items", axis=1)[['created', 'key', 'toString','fromString']]
  # Create the backlog transitions
  create_transitions = base.copy()
  create_transitions['toString'] = 'Backlog'
  # Combine the transitions and the Backlog dates
  transitions = pd.concat([transitions, create_transitions])
  transitions
  # Pivot the statuses
  #statuses = transitions.pivot(index=['key','created','fromString'],values=('created'), columns=('toString'))
  # Make sure all fields are of datetime
  #statuses = statuses.astype('datetime64[ns]')
  #statuses.rename(columns={'toString': 'Status'}, inplace=True)
  #statuses


  #statuses = statuses.drop('New', axis=1)
  #statuses = statuses.drop('Prioritization', axis=1)    
  #statuses = statuses.drop('Workshop', axis=1)  
  
  statuses = transitions
  print(statuses.columns)

  print('Final Total AS Fetched :', len(statuses))

  # getting the current date and time
  current_datetime = datetime.now()
  current_date_time = current_datetime.strftime("%m-%d-%Y")
  print("current date and time = ",current_date_time)

  gcs_bucket_name = "bkt-prod-dwh-svc-00-jira-issues-statuses"
  gcs_bucket_name 
  gcs_filepath = 'gs://{}/custom_as_bak'.format(gcs_bucket_name)

  gcs_filepath = gcs_filepath +"-"+ str(current_date_time) + ".csv"
  print(gcs_filepath)
  #df.columns = df.columns.str.replace('.', '_')

  statuses.to_csv(gcs_filepath)

  return statuses

def hello_http(request):
  df = get_statuses_write_to_gcs()
  df.head(3)
  return {'response' : 'Success'}



