from google.cloud import bigquery
from google.cloud import storage
import os
import pandas as pd
from datetime import datetime,timedelta
import pyodbc

def get_project_statuses_write_to_gcs():
  project_id = "bkt-nonprod-dev-dwh-svc-00"
  dataset_id = "bq_dataset_jira_statuses"
  table_id = "bq_jira_statuses_tbl"

  print(project_id)

  bq_client = bigquery.Client(project = project_id)

  # job_config = bigquery.QueryJobConfig()
  query = "SELECT * FROM `{}.{}.{}`".format(project_id,dataset_id, table_id)
  print(query)

  # query_job = bq_client.query(job_config)
  # results = query_job.result()


  df = pd.read_gbq(query,
                  project_id=project_id
                  ,dialect="standard")

  #Connection to SQL Server
  conn = pyodbc.connect('Driver={SQL Server};'
                          'Server=MKTDWPRDSQL;'
                          'Database=DBA;'
  #                        'UID=data_analytics_ro;'
  #                        'PWD=Welcome!;'
                          'Trusted_Connection=yes;')
  cursor = conn.cursor()
  # print(cursor)

  #create a Table 
  cursor.execute('''
                drop table if exists DBA.dbo.Jira_History
                CREATE TABLE DBA.dbo.Jira_History (
                    created datetime,
                    [Key] varchar(100),
                    toString varchar(100),
                    fromString varchar(100)
                )''')

  print('before inserting: ', datetime.now())

  for row in df.itertuples():
      cursor.execute('''
                    INSERT INTO DBA.dbo.Jira_History
                    (created , [Key], toString, fromString)
                    VALUES(?,?,?,?)
                    ''',
                    row.created,
                    row.Key, 
                    row.toString,
                    row.fromString
                    
                    )
      
  print('After inserting: ', datetime.now())    

  print(conn)
  conn.commit()
  conn.close()

  # return project_statuses  

def hello_http(request):
  get_project_statuses_write_to_gcs()
  # df.head(3)
  return {'response' : 'Success'}



