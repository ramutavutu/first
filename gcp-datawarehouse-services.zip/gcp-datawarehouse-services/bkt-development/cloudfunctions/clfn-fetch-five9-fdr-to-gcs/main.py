#Final Five9
from requests.auth import HTTPBasicAuth
import json
import pandas as pd
import csv
from io import StringIO
from datetime import datetime
from google.cloud import storage
import os
import requests
#import gcsfs
from google.cloud import bigquery

import base64
from datetime import datetime, timedelta
import io
import xml.etree.ElementTree as ET
import time
import numpy as np
import re
import requests
from requests.exceptions import HTTPError

import asyncio
import requests
import base64
import pandas as pd
from datetime import datetime, timedelta
import io
import time
import xml.etree.ElementTree as ET


# generate encoded auth credentials
def generate_basic_auth_credentials():
    # Combine the username and password with a colon separator
    #username = 'powershell@wf' # provide username
    #username = 'powershell@bac' # provide username        
    username = 'powershell@b2s' # provide username
    password = 'Oper@tions111' # provide password
    credentials = f"{username}:{password}"

    # Encode the credentials as base64
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')

    # Return the base64-encoded credentials
    return encoded_credentials


# convert csv string to dataframe
def csv_to_dataframe(csv_string):
    # Create an input stream from the CSV string
    stream = io.StringIO(csv_string)

    # Read the CSV into a DataFrame
    data = pd.read_csv(stream)

    return data


# Define an async method that returns a DataFrame
async def update_is_running(report_df):
    # Perform some asynchronous operations
    await asyncio.sleep(30)  # Simulate async operation
    for index, value in enumerate(report_df['is_report_ready']):
        if value == 'true':
            report_id = report_df.loc[index, 'report_id']
            is_running = is_report_running(report_id)
            report_df.loc[report_df['report_id'] == report_id, 'is_report_ready'] = is_running
    return report_df


# last 24 hours report
def fetch_report(hour, delay, folder_name, report_name, short_report_name):
    # Get the current time
    current_time = datetime.now()
    report_id_list = []
    report_df = pd.DataFrame(columns=['report_id'])
    # Set the timezone offset (-07:00 in this example)
    timezone_offset = timedelta(hours=-7)

    # Calculate the start time (24 hours ago)
    start_time = current_time + timedelta(hours=-24) + timezone_offset
    rows = []
    # Create a loop to generate start and end times for each hour
    for i in range(hour):  # Calculate the end time (current hour)
        end_time = start_time + timedelta(hours=1)

        # Format the start and end times
        formatted_start_time = start_time.strftime('%Y-%m-%dT%H:%M:%S.000%z')
        formatted_end_time = end_time.strftime('%Y-%m-%dT%H:%M:%S.000%z')

        # call run_report
        return_id = run_report(folder_name, report_name, formatted_start_time,
                               formatted_end_time)
        # append id in list
        # report_id_list.append(return_id)
        row = pd.DataFrame({'report_id': return_id}, index=[0])
        rows.append(row)
        # Append the row to the DataFrame
        # report_df = report_df.append(row, ignore_index=True)
        # Update the start time for the next iteration
        start_time = end_time

    # report_df = pd.DataFrame(report_id_list, columns=['report_id', 'is_report_ready'])
    report_df = pd.concat(rows, ignore_index=True)

    # Delay for one minute
    time.sleep(delay)
    df = pd.DataFrame()
    report_df['is_report_running'] = True
    for report_id in report_df['report_id']:
        is_running = is_report_running(report_id)
        report_df.loc[report_df['report_id'] == report_id, 'is_report_running'] = is_running
    # print(len(df))
    # Loop over the values of 'is_report_ready'
    print(report_df)
    is_report_still_running = 'true' in report_df['is_report_running'].values
    if is_report_still_running:
        print ("Report is still running" )
        report_df =  update_is_running(report_df)
        # Delay for one minute
    time.sleep(delay)
    for index, value in enumerate(report_df['is_report_running']):
        if value == 'false':
            report_id = report_df.loc[index, 'report_id']
            new_df = get_report_result_csv(report_id)
            df = pd.concat([df, new_df])
            # delay of 2 sec
            time.sleep(2)
    # dataframe to gcs
    dataframe_to_gcs(df, short_report_name)
    return df


# api to run report this will return the report_id
def run_report(folder_name, report_name, start_time, end_time):
    # Define the SOAP endpoint URL
    url = 'https://api.five9.com/wsadmin/v4/AdminWebService'

    # Define the SOAP request headers if any
    headers = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'Authorization': 'Basic ' + generate_basic_auth_credentials()
    }

    # Define the request body template
    body_template = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.admin.ws.five9.com/">
   <soapenv:Header/>
   <soapenv:Body>
      <ser:runReport>
         <folderName>{folder_name}</folderName>
         <reportName>{report_name}</reportName>
         <criteria>
            <time>
               <end>{end_time}</end>
               <start>{start_time}</start>
            </time>
         </criteria>
      </ser:runReport>
   </soapenv:Body>
</soapenv:Envelope>'''

    # Populate the SOAP request body with the dynamic values
    soap_body = body_template.format(folder_name=folder_name, report_name=report_name, end_time=end_time,
                                     start_time=start_time)

    # Send the SOAP request
    response = requests.post(url, headers=headers, data=soap_body)

    # Print the response content
    print(response.content.decode('utf-8'))
    # Parse the SOAP response
    root = ET.fromstring(response.content.decode('utf-8'))
    # Find the value of the <return> tag
    return_tag = root.find('.//return')
    # Extract the value
    if return_tag is not None:
        return return_tag.text
        # print (return_id)
        # report_id_list.append(return_id)


# api to check if report is still running or completed
def is_report_running(report_id):
    # Define the SOAP endpoint URL
    url = 'https://api.five9.com/wsadmin/v4/AdminWebService'

    # Define the SOAP request headers if any
    headers = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'Authorization': 'Basic ' + generate_basic_auth_credentials()
    }

    # Define the request body template
    body_template = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.admin.ws.five9.com/">;
   <soapenv:Header/>
   <soapenv:Body>
      <ser:isReportRunning>
         <identifier>{report_id}</identifier>
      </ser:isReportRunning>
   </soapenv:Body>
</soapenv:Envelope>'''

    # Populate the SOAP request body with the dynamic values
    soap_body = body_template.format(report_id=report_id)

    # Send the SOAP request
    response = requests.post(url, headers=headers, data=soap_body)

    # Print the response content
    root = ET.fromstring(response.content.decode('utf-8'))
    return_tag = root.find('.//return')
    # Extract the value
    if return_tag is not None:
        return return_tag.text
    # return return_tag.text


# api will return the report as csv string
def get_report_result_csv(report_id):
    # Define the SOAP endpoint URL
    url = 'https://api.five9.com/wsadmin/v4/AdminWebService'

    # Define the SOAP request headers if any
    headers = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'Authorization': 'Basic ' + generate_basic_auth_credentials()
    }

    # Define the request body template
    body_template = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.admin.ws.five9.com/">;
   <soapenv:Header/>
   <soapenv:Body>
      <ser:getReportResultCsv>
         <identifier>{report_id}</identifier>
      </ser:getReportResultCsv>
   </soapenv:Body>
</soapenv:Envelope>'''

    # Populate the SOAP request body with the dynamic values
    soap_body = body_template.format(report_id=report_id)

    # Send the SOAP request
    response = requests.post(url, headers=headers, data=soap_body)

    # Print the response content
    print(response.content)
    root = ET.fromstring(response.content.decode('utf-8'))
    # Find the value of the <return> tag
    return_tag = root.find('.//return')
    # Extract the value
    csv_string = return_tag.text
    new_df = csv_to_dataframe(csv_string)
    return new_df


def dataframe_to_gcs(df, short_report_name):
    current_datetime = datetime.now()
    current_date_time = current_datetime.strftime('%m-%d-%Y')
    print('current date and time = ', current_date_time)
    gcs_bucket_name = "bkt-nonprod-dev-dwh-svc-00-five9" # bucket name 
    gcs_filepath = 'gs://{}/custom_as'.format(gcs_bucket_name)
    #report_name = "wf"
    gcs_filepath = gcs_filepath + '-' + short_report_name + '-' + str(current_date_time) + '.csv'
    print(gcs_filepath)
    df.to_csv(gcs_filepath)


def hello_http(request):
  df = fetch_report(24,60,'Shared Reports', 'Daily Call Log (Products)','fdr')
  df.head(3)
  return {'response' : 'Success'}



