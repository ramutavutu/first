## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |
| <a name="provider_google-beta"></a> [google-beta](#provider\_google-beta) | n/a |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google-beta_google_sql_database_instance.sql_instance](https://registry.terraform.io/providers/hashicorp/google-beta/latest/docs/resources/google_sql_database_instance) | resource |
| [google_monitoring_alert_policy.failed_uploaded_audits_alert](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_alert_policy) | resource |
| [google_monitoring_notification_channel.sql_alert_emails](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_notification_channel) | resource |
| [google_project_iam_member.secretAccessor](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member) | resource |
| [google_project_iam_member.secretmanager_viewer](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member) | resource |
| [google_storage_bucket.mssql_auditlog_bucket](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket) | resource |
| [google_storage_bucket_iam_member.storage_admin](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket_iam_member) | resource |
| [random_id.database_name_suffix](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) | resource |
| [google_secret_manager_secret_version.mssql_admin_password](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/secret_manager_secret_version) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alert_policy_labels"></a> [alert\_policy\_labels](#input\_alert\_policy\_labels) | n/a | `map(string)` | n/a | yes |
| <a name="input_availability_type"></a> [availability\_type](#input\_availability\_type) | n/a | `any` | n/a | yes |
| <a name="input_database_version"></a> [database\_version](#input\_database\_version) | n/a | `any` | n/a | yes |
| <a name="input_deletion_protection"></a> [deletion\_protection](#input\_deletion\_protection) | n/a | `bool` | n/a | yes |
| <a name="input_devops_sa"></a> [devops\_sa](#input\_devops\_sa) | n/a | `any` | n/a | yes |
| <a name="input_disk_autoresize"></a> [disk\_autoresize](#input\_disk\_autoresize) | n/a | `bool` | n/a | yes |
| <a name="input_disk_autoresize_limit"></a> [disk\_autoresize\_limit](#input\_disk\_autoresize\_limit) | n/a | `any` | n/a | yes |
| <a name="input_disk_size"></a> [disk\_size](#input\_disk\_size) | n/a | `any` | n/a | yes |
| <a name="input_disk_type"></a> [disk\_type](#input\_disk\_type) | n/a | `any` | n/a | yes |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | n/a | `any` | n/a | yes |
| <a name="input_project_id_sec"></a> [project\_id\_sec](#input\_project\_id\_sec) | n/a | `any` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | n/a | `any` | n/a | yes |
| <a name="input_sql_adminpass_sec_name"></a> [sql\_adminpass\_sec\_name](#input\_sql\_adminpass\_sec\_name) | n/a | `any` | n/a | yes |
| <a name="input_sql_alert_email_list"></a> [sql\_alert\_email\_list](#input\_sql\_alert\_email\_list) | n/a | `map(string)` | n/a | yes |
| <a name="input_subnetwork"></a> [subnetwork](#input\_subnetwork) | n/a | `any` | n/a | yes |
| <a name="input_tier"></a> [tier](#input\_tier) | n/a | `any` | n/a | yes |
| <a name="input_time_zone"></a> [time\_zone](#input\_time\_zone) | n/a | `any` | n/a | yes |
| <a name="input_user_labels"></a> [user\_labels](#input\_user\_labels) | n/a | `map(string)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_db_instance_name"></a> [db\_instance\_name](#output\_db\_instance\_name) | The instance name for the master instance |
| <a name="output_db_instance_service_account"></a> [db\_instance\_service\_account](#output\_db\_instance\_service\_account) | The service account email address assigned to the master instance |
| <a name="output_db_master_connection_name"></a> [db\_master\_connection\_name](#output\_db\_master\_connection\_name) | The connection name of the master instance to be used in connection strings |
| <a name="output_db_master_private_ip"></a> [db\_master\_private\_ip](#output\_db\_master\_private\_ip) | The master instance private ip address |
