# GCP Datawarehouse Service Repository.

## The infrastructure codes resides in the below directory

*  **📁 bkt-development** - Development environment terraform root module

*  **📁 bkt-partner** - Partner environment terraform root module

*  **📁 bkt-production** - Production environment terraform root module

*  **📁 cloudbuilder** - Cloudbuilder to setup terraform Docker image and pushed to the Artifact Registry

*  **📁 modules** - Datawarehouse infrastructure module
   *  **📁 ${gce-sql}** - Code template to deploy SQL on Compute Engine instance
      *  **📁 ${env}** - Terraform Root Module
      *  **📁 ${modules}** - Terraform Child Module
   *  **📁 ${mysql}** - Terraform module to deploy Cloud MYSQL
         *  **📁 ${env}** - Terraform Root Module
         *  **📁 ${modules}** - Terraform Child Module
   *  **📁 ${mssql}** - Terraform module to deploy Cloud MSSQL
         *  **📁 ${env}** - Terraform Root Module
         *  **📁 ${modules}** - Terraform Child Module
   *  **📁 ${terraform-google-bigquery}** - Bigquery Module
   *  **📁 ${terraform-google-composer}** - Cloud Composer Module
   *  **📁 ${terraform-google-dataflow}** - Cloud Dataflow Module
   *  **📁 ${terraform-google-datastream}** - Cloud Datastream Module
   *  **📁 ${terraform-google-gcs}** - Cloud GCS Module
   *  **📁 ${terraform-google-iam}** - IAM Module
   *  **📁 ${terraform-google-sa}** - Service Account Module

   
## Requirements


| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |
| <a name="requirement_google"></a> [google](#requirement\_google) | >= 4.8.0, < 5.0 |
| <a name="requirement_google-beta"></a> [google-beta](#requirement\_google-beta) | >= 4.8.0, < 5.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | >= 4.8.0, < 5.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_composer"></a> [composer](#module\_composer) | ../modules/terraform-google-composer/create_environment_v2 | n/a |
| <a name="module_composer_destination_bucket"></a> [composer\_destination\_bucket](#module\_composer\_destination\_bucket) | ../modules/terraform-google-gcs | n/a |
| <a name="module_composer_staging_bucket"></a> [composer\_staging\_bucket](#module\_composer\_staging\_bucket) | ../modules/terraform-google-gcs | n/a |
| <a name="module_dataflow_jobs"></a> [dataflow\_jobs](#module\_dataflow\_jobs) | ../modules/terraform-google-dataflow | n/a |
| <a name="module_dataflow_producer_project_iam_binding"></a> [dataflow\_producer\_project\_iam\_binding](#module\_dataflow\_producer\_project\_iam\_binding) | ../modules/terraform-google-iam/projects_iam | n/a |
| <a name="module_datastream"></a> [datastream](#module\_datastream) | ../modules/terraform-google-datastream | n/a |
| <a name="module_devops_project_app_dwh_iam_binding"></a> [devops\_project\_app\_dwh\_iam\_binding](#module\_devops\_project\_app\_dwh\_iam\_binding) | ../modules/terraform-google-iam/projects_iam | n/a |
| <a name="module_devops_project_iam_binding"></a> [devops\_project\_iam\_binding](#module\_devops\_project\_iam\_binding) | ../modules/terraform-google-iam/projects_iam | n/a |
| <a name="module_devops_tf_db_secret"></a> [devops\_tf\_db\_secret](#module\_devops\_tf\_db\_secret) | ../modules/terraform-google-iam/projects_iam | n/a |

## Resources

| Name | Type |
|------|------|
| [google_monitoring_alert_policy.datastream_data_freshness](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_alert_policy) | resource |
| [google_monitoring_alert_policy.datastream_unssuported_events](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_alert_policy) | resource |
| [google_monitoring_alert_policy.failed_composer_dags_run](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_alert_policy) | resource |
| [google_monitoring_alert_policy.failed_composer_tasks_run](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_alert_policy) | resource |
| [google_monitoring_alert_policy.failed_dataflow_job](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_alert_policy) | resource |
| [google_monitoring_alert_policy.failed_dataflow_pubsub_publish](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_alert_policy) | resource |
| [google_monitoring_notification_channel.alert_emails](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/monitoring_notification_channel) | resource |
| [google_project_iam_member.composer_sa_project_iam_binding](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member) | resource |
| [google_project_iam_member.composer_sa_sec_project_iam_binding](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member) | resource |
| [google_project_iam_member.dataflow_sa_iam_roles](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member) | resource |
| [google_service_account.cloud_composer_sa](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/service_account) | resource |
| [google_service_account.dataflow_service_account](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/service_account) | resource |
| [google_project.project](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/project) | data source |
| [google_secret_manager_secret_version_access.mssql_admin_password](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/secret_manager_secret_version_access) | data source |
| [google_storage_project_service_account.gcs_account](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/storage_project_service_account) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_alert_policy_labels"></a> [alert\_policy\_labels](#input\_alert\_policy\_labels) | Alerting | `map(string)` | n/a | yes |
| <a name="input_autoscaling_algorithm"></a> [autoscaling\_algorithm](#input\_autoscaling\_algorithm) | Dataflow autoscalling | `string` | n/a | yes |
| <a name="input_composer_gcs_force_destroy"></a> [composer\_gcs\_force\_destroy](#input\_composer\_gcs\_force\_destroy) | Composer staging GCS force destroy. Allow terraform to destroy bucket. Set to false in higher environment | `string` | n/a | yes |
| <a name="input_composer_gcs_storage_class"></a> [composer\_gcs\_storage\_class](#input\_composer\_gcs\_storage\_class) | Composer staging GCS storage class | `string` | `"STANDARD"` | no |
| <a name="input_dataflow_jobs"></a> [dataflow\_jobs](#input\_dataflow\_jobs) | List of dataflow jobs | <pre>list(object({<br>    pubsub_topic_name           = string<br>    pubsub_subscriber_name      = string<br>    dataflowjob_name            = string<br>    dataflow_tmp_subnet         = string<br>    max_num_workers             = number<br>    merge_frequency_minutes     = number<br>    dataflow_net_tag            = string<br>    bkt_bq_dataset_id           = string<br>    bkt_bq_dataset_friendlyname = string<br>    datastream_gcs_dest_bucket  = string<br>  }))</pre> | n/a | yes |
| <a name="input_dataflow_sa_displayname"></a> [dataflow\_sa\_displayname](#input\_dataflow\_sa\_displayname) | Dataflow service account display name | `string` | n/a | yes |
| <a name="input_dataflow_sa_id"></a> [dataflow\_sa\_id](#input\_dataflow\_sa\_id) | Dataflow service account id | `string` | n/a | yes |
| <a name="input_datastreams"></a> [datastreams](#input\_datastreams) | Datastream >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> | <pre>list(object({<br>    display_name  = string<br>    stream_id     = string<br>    desired_state = string<br>    labels        = map(string)<br><br>    source_config = object({<br>      include_objects = object({<br>        mysql_databases = optional(list(object({<br>          database     = string<br>          mysql_tables = optional(list(string))<br>        })))<br>        postgresql_schema = optional(list(object({<br>          schema            = string<br>          postgresql_tables = optional(list(string))<br>        })))<br>      })<br>      postgres_replication_slot = optional(string)<br>      postgres_publication      = optional(string)<br>    })<br><br>    destination_config = object({<br>      gcs_destination_config = optional(object({<br>        file_rotation_mb       = number<br>        file_rotation_interval = string<br>        file_type              = string<br>      }))<br>      bigquery_destination_config = optional(object({<br>        data_freshness = string<br>      }))<br>    })<br><br>    source_connection = object({<br>      type                  = string<br>      display_name          = string<br>      connection_profile_id = string<br>      db_password           = string<br>      mysql_profile = optional(object({<br>        hostname = string<br>        username = string<br>      }))<br>      postgres_profile = optional(object({<br>        hostname = string<br>        username = string<br>        database = string<br>      }))<br><br>      // Extended for postgres and oracle<br><br>    })<br><br>    destination_connection = object({<br>      type                  = string // Values - gcs, bq<br>      display_name          = string<br>      connection_profile_id = string<br><br>      gcs_profile = optional(object({<br>        bucket        = string<br>        storage_class = string<br>      }))<br><br>    })<br><br><br>  }))</pre> | n/a | yes |
| <a name="input_devops_project_num"></a> [devops\_project\_num](#input\_devops\_project\_num) | Devops project number | `string` | n/a | yes |
| <a name="input_devops_sa"></a> [devops\_sa](#input\_devops\_sa) | Devops Service Account email ID | `string` | n/a | yes |
| <a name="input_dwh_project_num"></a> [dwh\_project\_num](#input\_dwh\_project\_num) | Datawahouse project number | `string` | n/a | yes |
| <a name="input_environments"></a> [environments](#input\_environments) | List of environment configurations. | <pre>list(object({<br>    name                             = string<br>    composer_subnetwork_name         = string<br>    pod_ip_allocation_range_name     = string<br>    service_ip_allocation_range_name = string<br>    composer_environment_size        = string<br>    composer_scheduler = object({<br>      cpu        = string<br>      memory_gb  = number<br>      storage_gb = number<br>      count      = number<br>    })<br>    image_version = string<br>    composer_web_server = object({<br>      cpu        = string<br>      memory_gb  = number<br>      storage_gb = number<br>    })<br>    composer_worker = object({<br>      cpu        = string<br>      memory_gb  = number<br>      storage_gb = number<br>      min_count  = number<br>      max_count  = number<br>    })<br>    tags               = list(string)<br>    pypi_packages      = map(string)<br>    staging_bucket     = string<br>    destination_bucket = string<br>    labels             = map(string)<br>  }))</pre> | `[]` | no |
| <a name="input_labels"></a> [labels](#input\_labels) | Environment Common label | `map(string)` | n/a | yes |
| <a name="input_maintenance_end_time"></a> [maintenance\_end\_time](#input\_maintenance\_end\_time) | Time window specified for recurring maintenance operations in RFC3339 format | `string` | `"2023-04-30T03:30:00-05:00"` | no |
| <a name="input_maintenance_recurrence"></a> [maintenance\_recurrence](#input\_maintenance\_recurrence) | Frequency of the recurring maintenance window in RFC5545 format. | `string` | `"FREQ=WEEKLY;BYDAY=SA,SU,MO"` | no |
| <a name="input_maintenance_start_time"></a> [maintenance\_start\_time](#input\_maintenance\_start\_time) | Time window specified for daily or recurring maintenance operations in RFC3339 format | `string` | `"2023-04-29T23:30:00-05:00"` | no |
| <a name="input_network_name"></a> [network\_name](#input\_network\_name) | Datawahouse dev VPC network name | `string` | n/a | yes |
| <a name="input_on_delete"></a> [on\_delete](#input\_on\_delete) | Behavior of deletion during terraform destroy. drain or cancel accepted values | `string` | n/a | yes |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | Datawahouse project id | `string` | n/a | yes |
| <a name="input_project_id_host"></a> [project\_id\_host](#input\_project\_id\_host) | Host network project id | `string` | n/a | yes |
| <a name="input_project_id_sec"></a> [project\_id\_sec](#input\_project\_id\_sec) | Secretes project id | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Environment region | `string` | n/a | yes |
| <a name="input_sql_alert_email_list"></a> [sql\_alert\_email\_list](#input\_sql\_alert\_email\_list) | n/a | `map(string)` | n/a | yes |
| <a name="input_template_gcs_path"></a> [template\_gcs\_path](#input\_template\_gcs\_path) | Google provided dataflow template path. gs://dataflow-templates-us-east1/latest/flex/Cloud\_Datastream\_to\_BigQuery | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_airflow_uri"></a> [airflow\_uri](#output\_airflow\_uri) | URI of the Apache Airflow Web UI hosted within the Cloud Composer Environment. |
| <a name="output_composer_env_id"></a> [composer\_env\_id](#output\_composer\_env\_id) | ID of Cloud Composer Environment. |
| <a name="output_composer_env_name"></a> [composer\_env\_name](#output\_composer\_env\_name) | Name of the Cloud Composer Environment. |
| <a name="output_gcs_bucket"></a> [gcs\_bucket](#output\_gcs\_bucket) | Google Cloud Storage bucket which hosts DAGs for the Cloud Composer Environment. |
| <a name="output_gke_cluster"></a> [gke\_cluster](#output\_gke\_cluster) | Google Kubernetes Engine cluster used to run the Cloud Composer Environment. |

