#Final
from requests.auth import HTTPBasicAuth
import json
import pandas as pd
import csv
from io import StringIO
from datetime import datetime
from google.cloud import storage
import os
import requests
#import gcsfs
from google.cloud import bigquery

import time
import numpy as np
import re
import requests
from requests.exceptions import HTTPError

def load_jira_project_statuses_cat_data_all_from_gcs_to_bq():

  project_id = "bkt-prod-dwh-svc-00"
  print(project_id)

  bq_client = bigquery.Client(project = project_id)
  #bq_client = bigquery.Client()
  # getting the current date and time
  current_datetime = datetime.now()
  current_date_time = current_datetime.strftime("%m-%d-%Y")
  print("current date and time = ",current_date_time)

  gcs_bucket_name = "bkt-prod-dwh-svc-00-jira-issues-statuses"
  gcs_bucket_name 
  gcs_filepath = 'gs://{}/custom_project_statuses_cat'.format(gcs_bucket_name)
  gcs_filepath = gcs_filepath +"-"+ str(current_date_time) + ".csv"
  print(gcs_filepath)

  data_aset_name = "bq_dataset_jira_statuses"
  print(data_aset_name)

  df_new_read = pd.read_csv(gcs_filepath)

  print("Total Final AS From GCS Bucket : " ) 
  print(len(df_new_read)) 
  print(df_new_read.columns)

  df_new_read = df_new_read.drop('Unnamed: 0', axis=1)

  #df_new_read = df_new_read.drop('key', axis=1)
  #df_new_read = df_new_read.drop('created', axis=1)
  #df_new_read = df_new_read.drop('fromString', axis=1)

  df_new_read.columns = df_new_read.columns.str.replace(' ', '')
  df_new_read.columns = df_new_read.columns.str.replace('\(', '')
  df_new_read.columns = df_new_read.columns.str.replace('\)', '')
  df_new_read.columns = df_new_read.columns.str.replace('-', '_')
  df_new_read.columns = df_new_read.columns.str.replace('.', '_')  
  df_new_read.columns

  columns = ['key', 
            'fields_summary',
            'fields_issuetype_name',
            'fields_customfield_10018_data_key',
            'fields_customfield_10018_data_summary',
            'fields_created', 
            'fields_updated',
            'fields_status_name',
            'fields_status_statusCategory_name',
            'fields_customfield_10080_value',
            'fields_customfield_10184_value',
            'fields_customfield_10184_child_value',             
            'fields_customfield_10142_value',
            'fields_customfield_10044_value',
            'fields_customfield_10153_value',
            'fields_customfield_10172_value',
            'fields_customfield_10232_value',
            'fields_customfield_10160_value',
            'fields_customfield_10001_name',   
            'fields_customfield_10168_value',
            'fields_customfield_10169_value',
            'fields_customfield_10257',            
            'Intake Meeting' 
            ]

  df_new_read = pd.DataFrame(df_new_read, columns=columns)

  print(df_new_read.columns)
  #df_new_read['fields_created'] = pd.to_datetime(df_new_read['fields_created'])
  #df_new_read['fields_updated'] = pd.to_datetime(df_new_read['fields_updated'])
  df_new_read['fields_created'] = pd.to_datetime(df_new_read['fields_created'], utc=True)
  df_new_read['fields_updated'] = pd.to_datetime(df_new_read['fields_updated'], utc=True)
  #df_new_read['fields_created_est'] = df_new_read['fields_created'].dt.tz_convert('US/Eastern')
  #df_new_read['fields_updated_est'] = df_new_read['fields_updated'].dt.tz_convert('US/Eastern')
  print(df_new_read)
  print(df_new_read.dtypes)

  tbl_name = str(data_aset_name) + ".bq_jira_project_statuses_cat_tbl"
  print(tbl_name)
  dataset = bq_client.create_dataset(data_aset_name, exists_ok=True)


  #df_new_read.head(3)
  df_new_read.to_gbq(
      destination_table=tbl_name,
      project_id = project_id,
      if_exists="replace",  # 3 available methods: fail/replace/append
  )

  return df_new_read

def hello_http(request):
  df = load_jira_project_statuses_cat_data_all_from_gcs_to_bq()
  df.head(3)
  return {'response' : 'Success'}



