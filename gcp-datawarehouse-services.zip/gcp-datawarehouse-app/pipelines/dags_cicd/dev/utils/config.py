#Dag file location
DIR_NAME = "./gcp-app-development/composer/matomo-api-pipeline-dags/"

#Dag temp GCS location (Note: GCS path should match the path of DIR_NAME)
DAG_STAGING_GCS = "gcp-app-development/composer/matomo-api-pipeline-dags/" 

#Dag files
DAG_FILES = ["main.py"]

#Non Dag files
NON_DAG_FILES = ["__init__.py","config.py","mapping.py","config_test.py","main_test.py","mapping_test.py"]