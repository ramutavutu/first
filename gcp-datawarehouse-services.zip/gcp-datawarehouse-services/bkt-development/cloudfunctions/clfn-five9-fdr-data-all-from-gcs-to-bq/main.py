#Final Five9
from requests.auth import HTTPBasicAuth
import json
import pandas as pd
import csv
from io import StringIO
from datetime import datetime
from google.cloud import storage
import os
import requests
#import gcsfs
from google.cloud import bigquery

import time
import numpy as np
import re
from requests.exceptions import HTTPError
import traceback
from datetime import datetime, time, timedelta

def load_five9_data_all_from_gcs_to_bq(short_report_name):

  project_id = "bkt-nonprod-dev-dwh-svc-00"
  print(project_id)

  bq_client = bigquery.Client(project = project_id)
  #bq_client = bigquery.Client()
  # getting the current date and time
  current_datetime = datetime.now()
  current_date_time = current_datetime.strftime("%m-%d-%Y")
  print("current date and time = ",current_date_time)

  gcs_bucket_name = "bkt-nonprod-dev-dwh-svc-00-five9"
  gcs_bucket_name 
  #gcs_filepath = 'gs://{}/custom_as'.format(gcs_bucket_name)
  #gcs_filepath = gcs_filepath +"-"+ str(current_date_time) + ".csv"
  gcs_filepath = 'gs://{}/custom_as'.format(gcs_bucket_name)
  #gcs_filename = 'BAC - Call Data Daily (BAC QCB) v4.18.21 230505_122305'
  #report_name = "wf"
  #gcs_filepath = gcs_filepath + str(gcs_filename) + ".csv"
  gcs_filepath = gcs_filepath + '-' + short_report_name + '-' + str(current_date_time) + '.csv'  
  print(gcs_filepath)

  data_aset_name = "bq_dataset_five9"
  print(data_aset_name)

  df_new_read = pd.read_csv(gcs_filepath)

  print("Total Final AS From GCS Bucket : " ) 
  print(len(df_new_read)) 
  print(df_new_read.columns)

  #df_new_read = df_new_read.drop('Unnamed: 0', axis=1)
  #df_new_read = df_new_read.drop('key', axis=1)
  #df_new_read = df_new_read.drop('created', axis=1)
  #df_new_read = df_new_read.drop('fromString', axis=1)

  df_new_read = format_column_names(df_new_read)
  #df_new_read.columns

  print(df_new_read.columns)
  #df_new_read['created1'] = pd.to_datetime(df_new_read['created'])
  #df_new_read['created'] = pd.to_datetime(df_new_read['created'], utc=True)
  #df_new_read['created'] = df_new_read['created'].astype('datetime64[ns]')

  print(df_new_read)
  print(df_new_read.dtypes)

  tbl_name = str(data_aset_name) + ".bq_five9_" + short_report_name +"_tbl"
  print(tbl_name)
  dataset = bq_client.create_dataset(data_aset_name, exists_ok=True)

  df_new_read.head(3)
  df_new_read.to_gbq(
      destination_table=tbl_name,
      project_id = project_id,
      if_exists="replace",  # 3 available methods: fail/replace/append
  )

  #df_new_read.head(3)

  return df_new_read

def update_bac_ist_program_level(df):
    try:

        df = format_column_names(df)
        # print(df.columns)
        # ----[Agent Name None]--BD
        if 'AgentName' not in df.columns:
            df['AgentName'] = None
        df['AgentName'] = df.apply(
            lambda row: 'Within Hours' if row['Client_Name'] == 'Bank of America' else 'Filter Out',
            axis=1)
        # ----IST COUNT---CV
        call_counts = df.groupby('CALLID').size().reset_index(name='Cou')
        df['ISTCOUNT'] = df['CALLID'].map(call_counts.set_index('CALLID')['Cou']).fillna(0)
        # ----IST Qwt---CV
        df['ISTQWT'] = df.apply(lambda row: datetime.strptime(row['QUEUEWAITTIME'], '%H:%M:%S').time() if row[
                                                                                                              'QUEUEWAITTIME'] is not None else None,
                                axis=1)
        df['ISTQWT'] = df['ISTQWT'].astype(str).map(lambda x: x.encode('utf-8') if x is not None else None)
        # ---CQ= [ADV Date]
        df['ADVDate'] = '1900-01-01'
        # ----CY--Count Call ID--
        b = df.groupby('CALLID')['CALLID'].count().reset_index(name='Cou')
        df = df.merge(b, on='CALLID', how='inner')
        df['CountCallID'] = df['Cou']
        df = df.drop('Cou', axis=1)
        #  ---CountIF QCB Added  CZ
        b_temp = df[df['CALLTYPE'] == 'QueueCallback'].groupby('CALLID')['CALLID'].count().reset_index(name='Cou')
        df = df.merge(b_temp, on='CALLID', how='left')
        df['CountIFQCBAdded'] = df.apply(lambda row: row['Cou'] if row['CountCallID'] > 1 else 0, axis=1)
        df = df.drop('Cou', axis=1)
        # Set QCB Registered All

        # df = update_qcb_registered(df)
        # Set QCB Registered All
        df['QCBRegisteredAll'] = df.apply(
            lambda x: 1 if x['CountIFQCBAdded'] == 1 and x['CALLTYPE'] == 'Inbound' and x[
                'QUEUECALLBACKREGISTERED'] == 0 else 0, axis=1)
        df['QUEUECALLBACKWAITTIME'] = df['QUEUECALLBACKWAITTIME'].astype(str)

        # Set QCB Registered
        def set_qcb_registered(row):
            if row['QCBRegisteredAll'] == 1:
                return 1
            else:
                if row['DISPOSITION'] == 'Duplicated Callback Request':
                    return 0
                else:
                    if row['QUEUECALLBACKWAITTIME'] > '00:00:00' or row['QUEUECALLBACKREGISTERED'] > 0 or row[
                        'QCB - Registered System'] > 0:
                        return 1
                    else:
                        return 0
        df['QCBRegistered'] = df.apply(set_qcb_registered, axis=1)
        #  ---CK  Count QCB Same Date
        # df = update_count_qcb_same_date(df)
        # Perform the join and aggregation
        b = df.groupby('DATE')['CALLID'].count().reset_index(name='Cou')
        df = pd.merge(df, b, on='DATE', how='inner')

        # Update the Order_Count column
        df['Order_Count'] = df['Cou']
        df_copy = df.copy()

        # Apply the SQL logic to update the copy of the DataFrame
        df_copy['CountQCBSameDate'] = df_copy.apply(
            lambda row: 2 if pd.Timestamp(row['ADVDate']) > pd.Timestamp('1900-01-01') and row['ADVDate'] == row[
                'DATE'] and row['QCBRegistered'] > 0 else (row['Order_Count'] if row['QCBRegistered'] > 0 else 0),
            axis=1
        )
        df = df_copy
        # --CB=Actual Handle Time
        df['ActualHandleTime'] = df.apply(
            lambda x: '00:00:00' if x['CALLTYPE'] == 'Inbound' and x['CountQCBSameDate'] >= 2 and x[
                'QCBRegistered'] == 1 else x['HANDLETIME'], axis=1)

        df['QUEUEWAITTIME'] = df['QUEUEWAITTIME'].apply(str_to_time)
        df['QUEUEWAITTIME'] = df['QUEUEWAITTIME'].astype(str).map(
            lambda x: x.encode('utf-8') if x is not None else None)
        df['ActualQueueWaitTime'] = df.apply(lambda row:
                                             '00:00:00' if row['DISPOSITION'] == 'QueueCallbackTimeout' and row[
                                                 'ISTCOUNT'] == 0
                                             else row['ISTQWT'] if row['ISTCOUNT'] > 0 and row['ISTQWT'] < row[
                                                 'QUEUEWAITTIME']
                                             else '00:00:00' if row['CALLTYPE'] == 'Inbound' and row[
                                                 'CountQCBSameDate'] >= 2 and row['QCBRegistered'] == 1
                                             else '00:00:00' if row['CALLTYPE'] == 'QueueCallback' and row[
                                                 'CountQCBSameDate'] >= 2 and row['QCBRegistered'] == 0
                                             else row['QUEUEWAITTIME'], axis=1)
        #df['ActualQueueWaitTime'] = df['ActualQueueWaitTime'].apply(str_to_time)
        #df['ActualHandleTime'] = df['ActualHandleTime'].apply(str_to_time)
        df['ActualQueueWaitTime'] = df['ActualQueueWaitTime'].astype(str).map(
            lambda x: x.encode('utf-8') if x is not None else None)
        df['ActualHandleTime'] = df['ActualHandleTime'].astype(str).map(
            lambda x: x.encode('utf-8') if x is not None else None)
        # --BE=Queue<300
        df['Queue<300'] = df.apply(
            lambda x: 1 if int(x['CALLID']) > 1 and str(x['ActualQueueWaitTime']) <= '00:00:01' else 0, axis=1)
        # ----BH=Queue<Goal
        df['Queue<Goal'] = df.apply(
            lambda x: 1 if x['Custom_Program'] == 'Basic' and str(x['ActualQueueWaitTime']) <= '00:00:30' else (
                1 if x['Custom_Program'] == 'Premium' and str(x['ActualQueueWaitTime']) <= '00:00:20' else (
                    1 if x['Custom_Program'] == '' and str(x['ActualQueueWaitTime']) <= '00:00:30' else 0)), axis=1)
        # --BS Good Call
        df['GoodCall'] = df.apply(lambda x: 'No' if x['AgentName'] == 'Filter Out' else (
            'No' if x['QCBRegistered'] == 1 else ('No' if x['DISPOSITION'] == 'Duplicated Callback Request' else (
                'No' if str(x['ActualHandleTime']) == '00:00:00' and x['Queue<Goal'] == 1 else (
                    'NO' if str(x['ActualHandleTime']) == '00:00:00' and x['Queue<Goal'] == 0 and x[
                        'QCBRegistered'] == 1 else 'Yes')))), axis=1)
        # ----BT=Good Call Offered
        df['GoodCallOffered'] = df.apply(
            lambda x: 0 if x['Client_Name'] == '0' else (1 if x['GoodCall'] == 'Yes' else 0), axis=1)
        # ----BU--Handled Formula
        df['HandledFormula'] = df.apply(lambda x: 0 if x['Client_Name'] == '0' else (
            1 if pd.notnull(x['ActualHandleTime']) and str(x['ActualHandleTime']) > '00:00:00' and x[
                'GoodCallOffered'] == 1 else 0), axis=1)
        # --BQ Abandoned Formula
        df['AbandonedFormula'] = df.apply(lambda row: 0 if row['Client_Name'] == '0' else (
            1 if str(row['ActualHandleTime']) == '00:00:00' and row['Queue<Goal'] == 0 and row[
                'GoodCallOffered'] == 1 else 0), axis=1)
        # ----CC-Good Call Handle Time
        df['GoodCallHandleTime'] = df.apply(lambda row: '' if (row['CALLTYPE'] == 'Inbound' and row[
            'HANDLETIME'] == '00:00:00' and row['Queue<Goal'] == 1) or (row['QCBRegistered'] == 1 and row[
            'HANDLETIME'] == '00:00:00') or (row['CALLTYPE'] == 'Queue Callback' and row[
            'HANDLETIME'] == '00:00:00') or (row['CALLTYPE'] == 'Inbound' and row[
            'DISPOSITION'] == 'Duplicated Callback Request') or row['AbandonedFormula'] == 1 else row[
            'ActualHandleTime'], axis=1)
        # ----CE QCB Connects
        df['QCBConnects'] = df.apply(
            lambda row: 1 if row['CALLTYPE'] == 'Queue Callback' and type(row['ActualHandleTime']) == datetime.time and
                             row['ActualHandleTime'].strftime('%H:%M:%S') > '00:00:00' else 0, axis=1)
        # --CD QCB Wait Time
        df['QCBWaitTime'] = df.apply(lambda row: '' if (
                row['CALLTYPE'] == 'Inbound' and row['GoodCallHandleTime'] == '00:00:00' and row[
            'QCBRegistered'] == 0) else
        ('' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] >= 2 and row['QCBRegistered'] == 1) else
         ('' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] >= 1 and row['QCBRegistered'] == 1) else
          ('00:00:00' if (row['CALLTYPE'] == 'Queue Callback' and row['CountQCBSameDate'] >= 2 and row[
              'QCBRegistered'] == 0) else row.get('SUM_QUEUECALLBACKWAITTIME', '00:00:00')))),
                                     axis=1)
        # --CM Index ANI DNIS
        df['IndexANIDNIS'] = 0
        # ----CI Duplicate Requests Count
        df['DuplicateRequestsCount'] = df.apply(
            lambda row: 3 if row['IndexANIDNIS'] > 0 and row['IndexANIDNIS'] != row['CALLID'] else (
                row['Order_Count'] if row['QCBRegistered'] > 0 else 0), axis=1)
        df['DuplicateRequestsCount'] = df.apply(
            lambda row: 1 if row['DISPOSITION'] == 'Duplicated Callback Request' else 0, axis=1)
        # ----BR Short Abandons
        df['ShortAbandons'] = df.apply(lambda row: 1 if row['DuplicateRequestsCount'] == 1 else
        (1 if (row['Queue<Goal'] == 1 and row['ActualHandleTime'] == '00:00:00') else
         (0 if (row['Queue<Goal'] == 0 and row['ActualHandleTime'] == '00:00:00') else
          (1 if (row['QCBRegistered'] == 1 or row['HandledFormula'] == 0) else 0))),
                                       axis=1)
        # --BW IVR Calls
        df['IVRCalls'] = df.apply(lambda row: 1 if int(row['CALLID']) > 1 else 0, axis=1)
        # ----BN QCB Offered
        df['QCBOffered'] = df.apply(lambda row: 1 if str(row['QUEUEWAITTIME']) > '00:00:03' or row[
            'Custom_QueueCallback_Offered'] == 1 else 0, axis=1)
        # --CF Custom Campaign Formula--
        df['CustomCampaignFormula'] = df.apply(
            lambda row: 'Expedia Migration' if row['CAMPAIGN'] == 'Bank of America - Expedia Inbound Transfer' or row[
                'CAMPAIGN'] == 'Bank of America - ML - Expedia Inbound Transfer' else row['Client_CustomClient'],
            axis=1)
        # --SUMifs EWT
        df_merged = df[df['Custom_EWT'] > 0].groupby(['DATE', 'HOUR', 'CustomCampaignFormula']).size().reset_index(
            name='Count')
        df_merged.rename(columns={'Count': 'CountifsEWT'}, inplace=True)
        df = pd.merge(df, df_merged, on=['DATE', 'HOUR', 'CustomCampaignFormula'], how='left')
        df['CountifsEWT'].fillna(0, inplace=True)
        df_sum = df[df['Custom_EWT'] > 0].groupby(['DATE', 'HOUR', 'CustomCampaignFormula'])[
            'Custom_EWT'].sum().reset_index(name='Count')
        df_sum['Count'] = df_sum['Count'].astype(int)
        df_sum.rename(columns={'Count': 'SumifsEWT'}, inplace=True)
        df = pd.merge(df, df_sum, on=['DATE', 'HOUR', 'CustomCampaignFormula'], how='left')
        df['SumifsEWT'].fillna(0, inplace=True)
        # ----AVGifs EWT
        df_filtered = df[(df['Custom_EWT'] != '') & (df['Custom_EWT'] != '10')]
        df_filtered['Custom_EWT'] = df_filtered['Custom_EWT'].astype(float)
        df_merged = df_filtered.groupby(['DATE', 'HOUR', 'CustomCampaignFormula'])[
            'Custom_EWT'].mean().round().reset_index(name='Cou')
        df_merged.rename(columns={'Cou': 'AVgifsEWT'}, inplace=True)
        df = pd.merge(df, df_merged, on=['DATE', 'HOUR', 'CustomCampaignFormula'], how='left')
        df['AVgifsEWT'].fillna(0, inplace=True)
        # -- --CU AVE EWT Quote
        df['AVEEWTQuote'] = df.apply(lambda row: 0 if row['Custom_EWT'] == 0 else (
            row.get('SumifsEWT', 0) if row['CountifsEWT'] == 1 else (
                row.get('AvgifsEWT', 0) if row['Custom_EWT'] == 10 else row['Custom_EWT'])), axis=1)
        # --BM-EWT Quoted -(Time)
        df['EWTQuoted_Time'] = df.apply(lambda row: '' if row['HandledFormula'] == 0 else (
            '' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] == 0 and row[
                'QCBRegistered'] == 0) else (
                '' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] == 2 and row[
                    'QCBRegistered'] == 1) else ('' if (
                        row['CALLTYPE'] == 'Queue Callback' and row['CountQCBSameDate'] == 2 and row[
                    'QCBRegistered'] == 0) else convert_to_time(float(row['AVEEWTQuote']) * 60)))), axis=1)
        # --BG-Queue Time
        df['ActualQueueWaitTime'] = df['ActualQueueWaitTime'].str.decode('utf-8')  # Convert bytes to string
        df['ActualQueueWaitTime'] = pd.to_datetime(df['ActualQueueWaitTime'])  # Convert string to datetime
        df['QueueTime'] = df.apply(
            lambda row: (row['ActualQueueWaitTime'].hour * 60) + row['ActualQueueWaitTime'].minute + (
                        row['ActualQueueWaitTime'].second / 60),
            axis=1)
        # --CH Queue > 10
        df['Queue>10'] = df['QueueTime'].apply(lambda x: 1 if x > 10 else 0)
        # --CL QCB Same Day Connects
        df['QCBSameDayConnects'] = df['CountQCBSameDate'].apply(lambda x: 1 if x == 2 else 0)
        # --[QCB Attempts]
        df['QCBAttempts'] = df['CALLTYPE'].apply(lambda x: 1 if x == 'QueueCallback' else 0)

    except Exception as e:
        traceback.print_exc()
        print(f"An error occurred: {str(e)}")
    return df

def update_wf_ist_program_level(df):
    # Update Queries will come here
    df = format_column_names(df)
    return df

def update_fdr_ist_program_level(df):
    # Update Queries will come here
    df = format_column_names(df)
    return df
    
def load_five9_final_data_all_from_gcs_to_bq(five9_after, short_report_name):

  #project_id = "bkt-nonprod-dev-dwh-svc-00"
  print(project_id)

  bq_client = bigquery.Client(project = project_id)

  data_aset_name = "bq_dataset_five9"
  print(data_aset_name)

  tbl_name = str(data_aset_name) + ".bq_five9_" + short_report_name +"_final_tbl"
  print(tbl_name)
  dataset = bq_client.create_dataset(data_aset_name, exists_ok=True)

  if short_report_name == 'bac':
    print("Creating final tables for "+short_report_name)
    five9_after_final = update_bac_ist_program_level(five9_after)
  elif short_report_name == 'wf':
    print("Creating final tables for "+short_report_name)
    five9_after_final = update_wf_ist_program_level(five9_after)
  elif short_report_name == 'fdr':
    print("Creating final tables for "+short_report_name)
    five9_after_final = update_fdr_ist_program_level(five9_after)
  else:
    print("Missing short_report_name : "+short_report_name)

  #five9_after_final = five9_after
  #five9_after_final = convert_datetime_to_bytes(five9_after_final)  
  five9_after_final.head(3)
  five9_after_final.to_gbq(
      destination_table=tbl_name,
      project_id = project_id,
      if_exists="replace",  # 3 available methods: fail/replace/append
  )

  #df_new_read.head(3)

  # Load into SQL Server
  return five9_after_final

def str_to_time(x):
    if not isinstance(x, str):
        return x
    if x == 'nan':
        x = '00:00:00'
    return datetime.strptime(x, '%H:%M:%S').time()

def format_column_names(df):
    df.columns = df.columns.str.replace(' ', '')
    df.columns = df.columns.str.replace('\(', '')
    df.columns = df.columns.str.replace('\)', '')
    df.columns = df.columns.str.replace('-', '_')
    df.columns = df.columns.str.replace('.', '_')
    df.columns = df.columns.str.replace('(', '_')
    df.columns = df.columns.str.replace(')', '_')
    return df

def convert_to_time(minutes):
    time = timedelta(minutes=minutes)
    return (datetime.min + time).time().strftime('%H:%M:%S')

def hello_http(request):
  df = load_five9_data_all_from_gcs_to_bq('fdr')
  df.head(3)

  five9_after_final = load_five9_final_data_all_from_gcs_to_bq(df, 'fdr')
  five9_after_final.head(3)
  return {'response' : 'Success'}



