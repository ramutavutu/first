import functions_framework

@functions_framework.http
def hello_http(request):
    name = extrat_and_load()
    return 'Hello {}!'.format(name)

def extrat_and_load():
    try:
        # Source
        source_query  = "select * from party where status = 'SUSPENDED'"
        source_conn   = mysql.connector.connect(host="35.239.212.42", database = 'bakkt',user="dw-mkt-tango-ro", passwd="welcome123",use_pure=True)      
        source_df = pd.read_sql(source_query,source_conn)    
        
        # Destination
        client = bigquery.client()
        client.load_table_from_dataframe(source_df, "abc")

        return "Completed"

    except Exception as err:
        print(f"Unexpected {err=}, {type(err)=}")
        raise  