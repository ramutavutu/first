from requests.auth import HTTPBasicAuth
import json
import pandas as pd
import csv
from io import StringIO
from datetime import datetime
from google.cloud import storage
import os
import requests
#import gcsfs
from google.cloud import bigquery

import time
import numpy as np
import re
import requests
from requests.exceptions import HTTPError

def load_jira_statuses_data_all_from_gcs_to_bq():

  project_id = "bkt-prod-dwh-svc-00"
  print(project_id)

  bq_client = bigquery.Client(project = project_id)
  #bq_client = bigquery.Client()
  # getting the current date and time
  current_datetime = datetime.now()
  current_date_time = current_datetime.strftime("%m-%d-%Y")
  print("current date and time = ",current_date_time)

  gcs_bucket_name = "bkt-prod-dwh-svc-00-jira-issues-statuses"
  gcs_bucket_name 
  gcs_filepath = 'gs://{}/custom_as'.format(gcs_bucket_name)
  gcs_filepath = gcs_filepath +"-"+ str(current_date_time) + ".csv"
  print(gcs_filepath)

  data_aset_name = "bq_dataset_jira_statuses"
  print(data_aset_name)

  df_new_read = pd.read_csv(gcs_filepath)

  print("Total Final AS From GCS Bucket : " ) 
  print(len(df_new_read)) 
  print(df_new_read.columns)

  df_new_read = df_new_read.drop('Unnamed: 0', axis=1)

  #df_new_read = df_new_read.drop('key', axis=1)
  #df_new_read = df_new_read.drop('created', axis=1)
  #df_new_read = df_new_read.drop('fromString', axis=1)

  #df_new_read.columns = df_new_read.columns.str.replace(' ', '')
  #df_new_read.columns = df_new_read.columns.str.replace('\(', '')
  #df_new_read.columns = df_new_read.columns.str.replace('\)', '')
  #df_new_read.columns = df_new_read.columns.str.replace('-', '_')
  #df_new_read.columns

  print(df_new_read.columns)
  #df_new_read['created1'] = pd.to_datetime(df_new_read['created'])
  df_new_read['created'] = pd.to_datetime(df_new_read['created'], utc=True)

  #df_new_read['created'] = df_new_read['created'].astype('datetime64[ns]')

  print(df_new_read)
  print(df_new_read.dtypes)

  tbl_name = str(data_aset_name) + ".bq_jira_statuses_tbl"
  print(tbl_name)
  dataset = bq_client.create_dataset(data_aset_name, exists_ok=True)

  df_new_read.head(3)
  df_new_read.to_gbq(
      destination_table=tbl_name,
      project_id = project_id,
      if_exists="replace",  # 3 available methods: fail/replace/append
  )

  #df_new_read.head(3)


  # Load into SQL Server


  return df_new_read

def hello_http(request):
  df = load_jira_statuses_data_all_from_gcs_to_bq()
  df.head(3)
  return {'response' : 'Success'}



