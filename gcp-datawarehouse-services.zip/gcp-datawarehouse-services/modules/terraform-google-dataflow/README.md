# Google Dataflow
## This Terraform code configures various Google Cloud Platform components to create a streaming data processing system. The code performs the following tasks:

* **It creates a PubSub topic and subscription to receive real-time data**
* **Enables notification for Datastream/Dataflow Google Cloud Storage (GCS) and assigns IAM roles to a unique GCS service account to publish to PubSub**
* **Creates a BigQuery dataset to store processed data**
* **Creates a service account for Dataflow worker nodes**
* **Assigns various IAM roles to the Dataflow service account, including roles for PubSub, Dataflow, Artifact Registry, Compute Engine, and Storage**
* **Creates IAM roles specifically for a Dataflow project's producer service account in the same project**
* **Creates a Dataflow Flex Template job to process streaming data, using a container specified in a Google Cloud Storage path and configured with various input parameters**


## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.13 |
| <a name="requirement_google"></a> [google](#requirement\_google) | >= 4.8.0, < 5.0 |
| <a name="requirement_google-beta"></a> [google-beta](#requirement\_google-beta) | >= 4.8.0, < 5.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | >= 4.8.0, < 5.0 |
| <a name="provider_google-beta"></a> [google-beta](#provider\_google-beta) | >= 4.8.0, < 5.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google-beta_google_dataflow_flex_template_job.bkt_datastream_dataflow_job](https://registry.terraform.io/providers/hashicorp/google-beta/latest/docs/resources/google_dataflow_flex_template_job) | resource |
| [google_bigquery_dataset.bkt_datastream_dataset](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/bigquery_dataset) | resource |
| [google_pubsub_subscription.bkt_datastream_subscription](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/pubsub_subscription) | resource |
| [google_pubsub_topic.bkt_datastream_topic](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/pubsub_topic) | resource |
| [google_pubsub_topic_iam_binding.gcs_sa_binding](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/pubsub_topic_iam_binding) | resource |
| [google_storage_notification.notification](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_notification) | resource |
| [random_id.random_suffix](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_autoscaling_algorithm"></a> [autoscaling\_algorithm](#input\_autoscaling\_algorithm) | Dataflow autoscalling | `string` | n/a | yes |
| <a name="input_bkt_bq_dataset_friendlyname"></a> [bkt\_bq\_dataset\_friendlyname](#input\_bkt\_bq\_dataset\_friendlyname) | Bigquery dataset | `string` | n/a | yes |
| <a name="input_bkt_bq_dataset_id"></a> [bkt\_bq\_dataset\_id](#input\_bkt\_bq\_dataset\_id) | Bigquery dataset | `string` | n/a | yes |
| <a name="input_dataflow_net_tag"></a> [dataflow\_net\_tag](#input\_dataflow\_net\_tag) | Dataflow network tag | `string` | n/a | yes |
| <a name="input_dataflow_tmp_subnet"></a> [dataflow\_tmp\_subnet](#input\_dataflow\_tmp\_subnet) | Subnetwork where vm will be assigned | `string` | n/a | yes |
| <a name="input_dataflowjob_name"></a> [dataflowjob\_name](#input\_dataflowjob\_name) | Dataflow job name | `string` | n/a | yes |
| <a name="input_datastream_gcs_dest_bucket"></a> [datastream\_gcs\_dest\_bucket](#input\_datastream\_gcs\_dest\_bucket) | Datastream GCS Bucket Name | `string` | n/a | yes |
| <a name="input_gcs_account"></a> [gcs\_account](#input\_gcs\_account) | GCS Service Account Email ID | `string` | n/a | yes |
| <a name="input_max_num_workers"></a> [max\_num\_workers](#input\_max\_num\_workers) | The number of workers permitted to work on the job | `number` | n/a | yes |
| <a name="input_merge_frequency_minutes"></a> [merge\_frequency\_minutes](#input\_merge\_frequency\_minutes) | Job merge frequency per minutes | `number` | n/a | yes |
| <a name="input_on_delete"></a> [on\_delete](#input\_on\_delete) | Behavior of deletion during terraform destroy. drain or cancel accepted values | `string` | n/a | yes |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | Project ID | `string` | n/a | yes |
| <a name="input_pubsub_subscriber_name"></a> [pubsub\_subscriber\_name](#input\_pubsub\_subscriber\_name) | Datastream pubsub subsription name | `string` | n/a | yes |
| <a name="input_pubsub_topic_name"></a> [pubsub\_topic\_name](#input\_pubsub\_topic\_name) | Datastream pubsub topic name | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Region | `string` | n/a | yes |
| <a name="input_service_account_email"></a> [service\_account\_email](#input\_service\_account\_email) | Dataflow service account email | `string` | n/a | yes |
| <a name="input_template_gcs_path"></a> [template\_gcs\_path](#input\_template\_gcs\_path) | Google provided dataflow template path. gs://dataflow-templates-us-east1/latest/flex/Cloud\_Datastream\_to\_BigQuery | `string` | n/a | yes |

## Outputs

No outputs.

