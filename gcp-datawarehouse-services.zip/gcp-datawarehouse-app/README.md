# GCP Datawarehouse Application Repository.

## The application codes resides in the below directory

*  **📁 gcp-app-development** - Development application codes

*  **📁 gcp-app-partner** - Partner application codes

*  **📁 gcp-app-production** - Production application codes

## The Cloudbuild CICD pipeline to run push the application codes above

*  **📁 pipelines** #- Pipeline folder which is been used by the Cloudbuild triggers
   *  **📁 dags_cicd**
      *  **📁 ${dev}**
         *  **📁 ${utils}**
            * **add_dags_to_composer_test.py**
            * **add_dags_to_composer.py**
            * **config.py**
            * **noxfile_config.py**
            * **requirements-test.txt**
            * **requirements.txt**
         * **__init__.py**
         * **contraints.txt**
         * **noxfile_config.py**
         * **README.md**
         * **requirements-test.txt**
         * **requirements.txt**
      *  **📁 ${partner}**
      *  **📁 ${production}**
   *  **📁 terraform**
      *  **📁 ${dev}**
      *  **📁 ${partner}**
      *  **📁 ${production}**
      * **gcp-dev-matomo-add-dags-to-composer-cloudbuild.yaml** 
      * **gcp-dev-matomo-test-dags-cloudbuild.yaml**

      - Cloudbuild triggers whenever a pull request is raised to merge to the main branch and run unit test to make sure dag file is valid, then run python script in the add_dags_to_composer.py and terraform commands to sync the Dags files and required folder to a staing location in the Composer GCS, then copy the files from staging location to dags folder. Job can be view in the cloudbuild [Cloudbuild](https://console.cloud.google.com/cloud-build/builds?project=bkt-common-devops-00).
      