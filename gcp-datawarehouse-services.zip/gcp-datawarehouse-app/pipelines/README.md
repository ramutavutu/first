## GSUTIL Tarraform Pipeline

*   **📁 Terraform** 
    *   **📁 ${dev}** - Running gsutil command to upload files to the GCS bucket
        *   **main.tf**
        *   **proverders.tf**
        *   **variables.tf**
        *   **backend.tf**
        *   **terraform.tfvars**

### Prerequisite:
     - The devops service account running the module must have the following IAM roles
        - Storage Object Admin in the datawarehouse project
        - Compute Network User in the Host network project 
        - Cloud build Editor in the devops project
     - Enable the following API in all the projects
        - Compute Engine API
        - Cloud Build API
        - Resource Manager API
### How the modules work
     - We are making use of the Null resource which triggers and scan through codes in the directory specified, then call the local excel provisioner to run gsutil command and upload to the specified gcs bucket.
     - Note: The path to the source folder and destination GCS bucket resides in the terraform tfvars.
     - Cloudbuild trigger was created and provided pipeline/terraform/dev as the working directory in the cloudbuild substitution variables. 
### Cloudbuild Triggers configuration to run the Terraform modules
```
    - Provide the trigger name
    - Tag e.g (dwh-dev)
    - Sellect pull or push request depending on the trigger being created
    - Select the Application Repo and set the base branch to main or master ^(main)$
    - Expand the INCLUDED and IGNORED dropped down.
        - Included Files: Add the path of the directory for the cloudbuild to keep track of any changes. Cloud build will be triggered if their is any changes in the directory added. A folder name can be provided ending with /** to keep track of all the files in the folder. eg gcp-app-development/composer/matomo-api-pipeline/** to keep track of all the files in the matomo-api-pipeline folser or gcp-app-development/composer/matomo-api-pipeline/config.py which will only keep track of the config.py file in the directory. Cloudbuild will ignore any changes made to the other files in the directory or folder.
        - Ignored Files: Exeptional. Cloudbuild will stricktly ignore any changes made to the ignore file and no job will run

    - Select CLoud Build as the configuration file
    - Provide the path to the cloudbuild pull or push request yaml file that will run Terraform init, validate, plan and apply. eg pipelines/gcp-dev-matomo-pull-request.yaml
    - Under advanced, Provide the substitute variables. All the variables has been used inside the gcp-dev-matomo-pull-request.yaml  file and a value will be provided.

        - _ARTIFACT_BUCKET_NAME  :  - This is the GCS artifact location of the cloud builder. All the cloudbuild jobs will be pushed to the bucket
        - _DEFAULT_REGION        :  - Environment region
        - _DEVOPS_PROJECT_ID     :  - Devops project ID
        - _ENV                   : dev
        - _GAR_REPOSITORY        :  - CloudBuilder Terraform Artifact to use for the terraform build that resides in the Devops project Artifact Registry. [Artifact Registry](https://console.cloud.google.com/artifacts?referrer=search&project=bkt-common-devops-00)
        - _TF_ACTION             : plan  - Terraform action (plan or appy)
        - _WORKSTREAM_NAME       : dwh-dev
        - __WORKSTREAM_PATH      : pipelines/terraform/dev  - workstream path of the terraform directory location to apply TF commands.

    - Mark the require and approval for the push triggers to enforce additional approval before deployment

    - Select the appropriate Devops service account to run the Job

```