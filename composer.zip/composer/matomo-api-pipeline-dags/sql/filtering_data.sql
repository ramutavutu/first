-- Filtering only required columns from staging dataset to transformation dataset
BEGIN

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Delta_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate 
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.Delta_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_PSCU_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.WF_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.pnc_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.rbc_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Merchandise_Gift`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.scotia_Merchandise_Gift`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Apple`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Apple`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.rbc_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Apple`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.scotia_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Apple`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.WF_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.ua_Apple`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.ua_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Apple`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.pnc_Apple`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS INT64) AS DB_Visits_Web_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.bac_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS INT64) AS DB_Visits_Web_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_PSCU_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS INT64) AS DB_Visits_Web_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS INT64) AS DB_Visits_Web_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.WF_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS INT64) AS DB_Visits_Web_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.pnc_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS INT64) AS DB_Visits_Web_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.psg_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS INT64) AS DB_Visits_Web_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_Travel`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_EventTickets`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_EventTickets`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_CustomStore`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_PSCU_CustomStore`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_CustomStore`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.FDR_CustomStore`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_CustomStore`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.fsv_CustomStore`);

CREATE OR REPLACE TABLE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Chase`
AS SELECT CAST(Date AS DATETIME) AS Date, Unique_visitors, Visits, Actions, Visits_with_Conversions, CAST(Conversion_Rate AS STRING) AS Conversion_Rate,CAST(NULL AS INT64) AS db_visits_conversion,CAST(NULL AS STRING) AS db_conversion_rate
FROM (SELECT Date, Unique_visitors,Visits,Actions,Visits_with_Conversions,Conversion_Rate FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.Chase`);

END