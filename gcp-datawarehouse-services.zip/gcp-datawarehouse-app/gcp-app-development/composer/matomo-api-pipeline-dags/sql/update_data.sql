-- Updates and transformations of columns in the entire sql file.

-- Updating Delta_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Delta_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'Delta'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Delta_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Delta_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
------------------------------------------------------------------------------------------------------------


-- Updating FDR_PSCU_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FDR_PSCU'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
----------------------------------------------------------------------------------------------------


-- Updating FDR_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FDR'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
-----------------------------------------------------------------------------------------------------------


-- Updating WF_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'WF'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
-------------------------------------------------------------------------------------------------


-- Updating pnc_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'PNC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
------------------------------------------------------------------------------------------------


-- Updating fsv_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FSV'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating rbc_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'RBC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating scotia_Merchandise_Gift table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Merchandise_Gift` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'Scotia'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000, 20)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Merchandise_Gift`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Merchandise_Gift`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating FDR_Apple table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Apple` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FDR'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Apple`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Apple`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating rbc_Apple table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Apple` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'RBC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Apple`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.rbc_Apple`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating scotia_Apple table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Apple` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'Scotia'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Apple`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.scotia_Apple`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating WF_Apple table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Apple` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'WF'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Apple`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Apple`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating ua_Apple table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.ua_Apple` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'UA'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.ua_Apple`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.ua_Apple`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating pnc_Apple table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Apple` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'PNC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Apple`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Apple`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating bac_Travel table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'BAC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source NOT IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel` DMG
SET DMG.DB_Visits_Web_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'BAC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel`
SET db_visits_conversion = 0
WHERE db_visits_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel`
SET DB_Visits_Web_conversion = 0
WHERE DB_Visits_Web_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion+DB_Visits_Web_conversion)/visits * 100)
where db_visits_conversion IS NOT NULL and DB_Visits_Web_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.bac_Travel`
SET db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL and DB_Visits_Web_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating FDR_PSCU_Travel table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FDR_PSCU'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source NOT IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel` DMG
SET DMG.DB_Visits_Web_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FDR_PSCU'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel`
SET db_visits_conversion = 0
WHERE db_visits_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel`
SET DB_Visits_Web_conversion = 0
WHERE DB_Visits_Web_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion+DB_Visits_Web_conversion)/visits * 100)
where db_visits_conversion IS NOT NULL and DB_Visits_Web_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_Travel`
SET db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL and DB_Visits_Web_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating FDR_Travel table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FDR'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source NOT IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel` DMG
SET DMG.DB_Visits_Web_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'FDR'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel`
SET db_visits_conversion = 0
WHERE db_visits_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel`
SET DB_Visits_Web_conversion = 0
WHERE DB_Visits_Web_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion+DB_Visits_Web_conversion)/visits * 100)
where db_visits_conversion IS NOT NULL and DB_Visits_Web_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_Travel`
SET db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL and DB_Visits_Web_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating WF_Travel table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'WF'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source NOT IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel` DMG
SET DMG.DB_Visits_Web_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'WF'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel`
SET db_visits_conversion = 0
WHERE db_visits_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel`
SET DB_Visits_Web_conversion = 0
WHERE DB_Visits_Web_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion+DB_Visits_Web_conversion)/visits * 100)
where db_visits_conversion IS NOT NULL and DB_Visits_Web_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.WF_Travel`
SET db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL and DB_Visits_Web_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating pnc_Travel table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'PNC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (20) AND o.order_source NOT IN ('WEB_AGENT')
  AND ol.category NOT in ('Activities','Activites')
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel` DMG
SET DMG.DB_Visits_Web_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'PNC'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (20) AND o.order_source IN ('WEB_AGENT')
  AND ol.category NOT in ('Activities','Activites')
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel`
SET db_visits_conversion = 0
WHERE db_visits_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel`
SET DB_Visits_Web_conversion = 0
WHERE DB_Visits_Web_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion+DB_Visits_Web_conversion)/visits * 100)
where db_visits_conversion IS NOT NULL and DB_Visits_Web_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.pnc_Travel`
SET db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL and DB_Visits_Web_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating psg_Travel table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'PSG'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source NOT IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel` DMG
SET DMG.DB_Visits_Web_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'PSG'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id IN (20) AND order_source IN ('WEB_AGENT')
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel`
SET db_visits_conversion = 0
WHERE db_visits_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel`
SET DB_Visits_Web_conversion = 0
WHERE DB_Visits_Web_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion+DB_Visits_Web_conversion)/visits * 100)
where db_visits_conversion IS NOT NULL and DB_Visits_Web_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.psg_Travel`
SET db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL and DB_Visits_Web_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating fsv_Travel table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'FSV'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (20) AND o.order_source NOT IN ('WEB_AGENT')
  AND ol.category NOT in ('Activities','Activites')
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel` DMG
SET DMG.DB_Visits_Web_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'FSV'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (20) AND o.order_source IN ('WEB_AGENT')
  AND ol.category NOT in ('Activities','Activites')
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel`
SET db_visits_conversion = 0
WHERE db_visits_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel`
SET DB_Visits_Web_conversion = 0
WHERE DB_Visits_Web_conversion IS NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion+DB_Visits_Web_conversion)/visits * 100)
where db_visits_conversion IS NOT NULL and DB_Visits_Web_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_Travel`
SET db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL and DB_Visits_Web_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating fsv_EventTickets table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_EventTickets` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` AS o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'FSV'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (20)
  AND ol.category IN ('Activities', 'Activites')
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_EventTickets`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_EventTickets`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating FDR_PSCU_CustomStore table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_CustomStore` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` AS o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'FDR_PSCU'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (10100)
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_CustomStore`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_PSCU_CustomStore`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating FDR_CustomStore table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_CustomStore` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` AS o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'FDR'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (10100)
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_CustomStore`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.FDR_CustomStore`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
---------------------------------------------------------------------------------------------------


-- Updating fsv_CustomStore table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_CustomStore` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders` AS o
  INNER JOIN `{{params.Project_Name}}.{{params.Staging_Dataset}}.order_line` AS ol ON o.order_id = ol.order_id
  WHERE o.var_id = 'FSV'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND ol.supplier_id IN (10100)
  GROUP BY CAST(order_date AS DATE)
) AS a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_CustomStore`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.fsv_CustomStore`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
----------------------------------------------------------------------------------------------------


-- Updating Chase table 
UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Chase` DMG
SET DMG.db_visits_conversion = a.orders_count
FROM (
  SELECT CAST(order_date AS DATE) AS date, COUNT(*) AS orders_count
  FROM `{{params.Project_Name}}.{{params.Staging_Dataset}}.orders`
  WHERE var_id = 'Chase'
  AND EXTRACT(YEAR FROM order_date) = 2023
  AND EXTRACT(MONTH FROM order_date) = 01
  AND supplier_id NOT IN (20000)
  GROUP BY CAST(order_date AS DATE)
) a
WHERE a.date = CAST(DMG.date AS DATE);

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Chase`
SET db_conversion_rate = FORMAT('%2.2f%%', (db_visits_conversion/visits) * 100)
where db_visits_conversion IS NOT NULL;

UPDATE `{{params.Project_Name}}.{{params.Transformation_Dataset}}.Chase`
SET db_visits_conversion = 0, db_conversion_rate = '0'
WHERE db_visits_conversion IS NULL;
----------------------------------------------------------------------------------------------------------------

