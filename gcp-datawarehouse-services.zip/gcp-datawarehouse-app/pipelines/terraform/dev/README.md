## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_null"></a> [null](#provider\_null) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [null_resource.upload_folder_content](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_composer_dags_bucket_name"></a> [composer\_dags\_bucket\_name](#input\_composer\_dags\_bucket\_name) | Composer Dags bucket name without gs:// and dags prefix | `string` | n/a | yes |
| <a name="input_dags_stage_gcs_path"></a> [dags\_stage\_gcs\_path](#input\_dags\_stage\_gcs\_path) | Dags Staging GCS path | `string` | n/a | yes |
| <a name="input_project"></a> [project](#input\_project) | The project indicates the default GCP project all of your resources will be created in. | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The region will be used to choose the default location for regional resources. Regional resources are spread across several zones. | `string` | n/a | yes |

## Outputs

No outputs.
