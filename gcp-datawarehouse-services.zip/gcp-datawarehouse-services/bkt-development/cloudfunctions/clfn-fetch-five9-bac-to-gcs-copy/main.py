#Final Five9
from requests.auth import HTTPBasicAuth
import json
import pandas as pd
import csv
from io import StringIO
from datetime import datetime
from google.cloud import storage
import os
import requests
#import gcsfs
from google.cloud import bigquery

import base64
from datetime import datetime, timedelta
import io
import xml.etree.ElementTree as ET
import time
import numpy as np
import re
import requests
from requests.exceptions import HTTPError

import asyncio
import requests
import base64
import pandas as pd
from datetime import datetime, timedelta
import io
import xml.etree.ElementTree as ET
import traceback


# generate encoded auth credentials
def generate_basic_auth_credentials():
    # Combine the username and password with a colon separator
    #username = 'powershell@wf' # provide username
    username = 'powershell@bac' # provide username        
    #username = 'powershell@fdr' # provide username
    password = 'Oper@tions111' # provide password
    credentials = f"{username}:{password}"

    # Encode the credentials as base64
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')

    # Return the base64-encoded credentials
    return encoded_credentials


# convert csv string to dataframe
def csv_to_dataframe(csv_string):
    # Create an input stream from the CSV string
    stream = io.StringIO(csv_string)

    # Read the CSV into a DataFrame
    data = pd.read_csv(stream)

    return data


# Define an async method that returns a DataFrame
async def update_is_running(report_df):
    # Perform some asynchronous operations
    await asyncio.sleep(30)  # Simulate async operation
    for index, value in enumerate(report_df['is_report_ready']):
        if value == 'true':
            report_id = report_df.loc[index, 'report_id']
            is_running = is_report_running(report_id)
            report_df.loc[report_df['report_id'] == report_id, 'is_report_ready'] = is_running
    return report_df


# last 24 hours report
def fetch_report(hour, delay, folder_name, report_name, short_report_name):
    # Get the current time
    current_time = datetime.now()
    report_id_list = []
    report_df = pd.DataFrame(columns=['report_id'])
    # Set the timezone offset (-07:00 in this example)
    timezone_offset = timedelta(hours=-7)

    # Calculate the start time (24 hours ago)
    start_time = current_time + timedelta(hours=-24) + timezone_offset
    rows = []
    # Create a loop to generate start and end times for each hour
    for i in range(hour):  # Calculate the end time (current hour)
        end_time = start_time + timedelta(hours=1)

        # Format the start and end times
        formatted_start_time = start_time.strftime('%Y-%m-%dT%H:%M:%S.000%z')
        formatted_end_time = end_time.strftime('%Y-%m-%dT%H:%M:%S.000%z')

        # call run_report
        return_id = run_report(folder_name, report_name, formatted_start_time,
                               formatted_end_time)
        # append id in list
        # report_id_list.append(return_id)
        row = pd.DataFrame({'report_id': return_id}, index=[0])
        rows.append(row)
        # Append the row to the DataFrame
        # report_df = report_df.append(row, ignore_index=True)
        # Update the start time for the next iteration
        start_time = end_time

    # report_df = pd.DataFrame(report_id_list, columns=['report_id', 'is_report_ready'])
    report_df = pd.concat(rows, ignore_index=True)

    # Delay for one minute
    time.sleep(delay)
    df = pd.DataFrame()
    report_df['is_report_running'] = True
    for report_id in report_df['report_id']:
        is_running = is_report_running(report_id)
        report_df.loc[report_df['report_id'] == report_id, 'is_report_running'] = is_running
    # print(len(df))
    # Loop over the values of 'is_report_ready'
    print(report_df)
    is_report_still_running = 'true' in report_df['is_report_running'].values
    if is_report_still_running:
        print ("Report is still running" )
        report_df =  update_is_running(report_df)
        # Delay for one minute
    time.sleep(delay)
    for index, value in enumerate(report_df['is_report_running']):
        if value == 'false':
            report_id = report_df.loc[index, 'report_id']
            new_df = get_report_result_csv(report_id)
            df = pd.concat([df, new_df])
            # delay of 2 sec
            time.sleep(2)
    # dataframe to gcs
    dataframe_to_gcs(df, short_report_name)
    return df


# api to run report this will return the report_id
def run_report(folder_name, report_name, start_time, end_time):
    # Define the SOAP endpoint URL
    url = 'https://api.five9.com/wsadmin/v4/AdminWebService'

    # Define the SOAP request headers if any
    headers = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'Authorization': 'Basic ' + generate_basic_auth_credentials()
    }

    # Define the request body template
    body_template = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.admin.ws.five9.com/">
   <soapenv:Header/>
   <soapenv:Body>
      <ser:runReport>
         <folderName>{folder_name}</folderName>
         <reportName>{report_name}</reportName>
         <criteria>
            <time>
               <end>{end_time}</end>
               <start>{start_time}</start>
            </time>
         </criteria>
      </ser:runReport>
   </soapenv:Body>
</soapenv:Envelope>'''

    # Populate the SOAP request body with the dynamic values
    soap_body = body_template.format(folder_name=folder_name, report_name=report_name, end_time=end_time,
                                     start_time=start_time)

    # Send the SOAP request
    response = requests.post(url, headers=headers, data=soap_body)

    # Print the response content
    print(response.content.decode('utf-8'))
    # Parse the SOAP response
    root = ET.fromstring(response.content.decode('utf-8'))
    # Find the value of the <return> tag
    return_tag = root.find('.//return')
    # Extract the value
    if return_tag is not None:
        return return_tag.text
        # print (return_id)
        # report_id_list.append(return_id)


# api to check if report is still running or completed
def is_report_running(report_id):
    # Define the SOAP endpoint URL
    url = 'https://api.five9.com/wsadmin/v4/AdminWebService'

    # Define the SOAP request headers if any
    headers = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'Authorization': 'Basic ' + generate_basic_auth_credentials()
    }

    # Define the request body template
    body_template = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.admin.ws.five9.com/">;
   <soapenv:Header/>
   <soapenv:Body>
      <ser:isReportRunning>
         <identifier>{report_id}</identifier>
      </ser:isReportRunning>
   </soapenv:Body>
</soapenv:Envelope>'''

    # Populate the SOAP request body with the dynamic values
    soap_body = body_template.format(report_id=report_id)

    # Send the SOAP request
    response = requests.post(url, headers=headers, data=soap_body)

    # Print the response content
    root = ET.fromstring(response.content.decode('utf-8'))
    return_tag = root.find('.//return')
    # Extract the value
    if return_tag is not None:
        return return_tag.text
    # return return_tag.text


# api will return the report as csv string
def get_report_result_csv(report_id):
    # Define the SOAP endpoint URL
    url = 'https://api.five9.com/wsadmin/v4/AdminWebService'

    # Define the SOAP request headers if any
    headers = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'Authorization': 'Basic ' + generate_basic_auth_credentials()
    }

    # Define the request body template
    body_template = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.admin.ws.five9.com/">;
   <soapenv:Header/>
   <soapenv:Body>
      <ser:getReportResultCsv>
         <identifier>{report_id}</identifier>
      </ser:getReportResultCsv>
   </soapenv:Body>
</soapenv:Envelope>'''

    # Populate the SOAP request body with the dynamic values
    soap_body = body_template.format(report_id=report_id)

    # Send the SOAP request
    response = requests.post(url, headers=headers, data=soap_body)

    # Print the response content
    print(response.content)
    root = ET.fromstring(response.content.decode('utf-8'))
    # Find the value of the <return> tag
    return_tag = root.find('.//return')
    # Extract the value
    csv_string = return_tag.text
    new_df = csv_to_dataframe(csv_string)
    return new_df


def dataframe_to_gcs(df, short_report_name):
    current_datetime = datetime.now()
    current_date_time = current_datetime.strftime('%m-%d-%Y')
    print('current date and time = ', current_date_time)
    gcs_bucket_name = "bkt-nonprod-dev-dwh-svc-00-five9" # bucket name 
    gcs_filepath = 'gs://{}/custom_as'.format(gcs_bucket_name)
    #report_name = "wf"
    gcs_filepath = gcs_filepath + '-' + short_report_name + '-' + str(current_date_time) + '.csv'
    print(gcs_filepath)
    df.to_csv(gcs_filepath)


# ========== GCS to BQ Part Starts here

#Final Five9 -> GCS to BQ  STEP - 1

def format_column_names(df1):
  df1.columns = df1.columns.str.replace(' ', '')
  df1.columns = df1.columns.str.replace('\(', '')
  df1.columns = df1.columns.str.replace('\)', '')
  df1.columns = df1.columns.str.replace('-', '_')
  df1.columns = df1.columns.str.replace('.', '_')
  df1.columns = df1.columns.str.replace('(', '_')
  df1.columns = df1.columns.str.replace(')', '_')
  return df1

def load_five9_data_all_from_gcs_to_bq(short_report_name):

  project_id = "bkt-nonprod-dev-dwh-svc-00"
  print(project_id)

  bq_client = bigquery.Client(project = project_id)

  # getting the current date and time
  current_datetime = datetime.now()
  current_date_time = current_datetime.strftime("%m-%d-%Y")
  print("current date and time = ",current_date_time)

  gcs_bucket_name = "bkt-nonprod-dev-dwh-svc-00-five9"
  gcs_bucket_name

  gcs_filepath = 'gs://{}/custom_as'.format(gcs_bucket_name)
  #gcs_filename = 'BAC - Call Data Daily (BAC QCB) v4.18.21 230505_122305'

  gcs_filepath = gcs_filepath + '-' + short_report_name + '-' + str(current_date_time) + '.csv'
  print(gcs_filepath)

  data_aset_name = "bq_dataset_five9"
  print(data_aset_name)

  df1_new_read = pd.read_csv(gcs_filepath)

  print("Total Final AS From GCS Bucket : " )
  print(len(df1_new_read))
  print(df1_new_read.columns)

  df1_new_read = format_column_names(df1_new_read)

  print(df1_new_read.columns)

  print(df1_new_read)
  print(df1_new_read.dtypes)

  tbl_name = str(data_aset_name) + ".bq_five9_" + short_report_name +"_tbl"
  print(tbl_name)
  dataset = bq_client.create_dataset(data_aset_name, exists_ok=True)

  df1_new_read.head(3)
  df1_new_read.to_gbq(
      destination_table=tbl_name,
      project_id = project_id,
      if_exists="replace",  # 3 available methods: fail/replace/append
  )


  # Load into SQL Server

  return df1_new_read

#Run the function Final  STEP - 2
five9_after = load_five9_data_all_from_gcs_to_bq('bacqcb') #bacqcb
five9_after_bac = five9_after
print(five9_after_bac)

#Final Five9 BAC final Table STEP - 3


def update_bac_qcb_program_level(df1):
    try:

        df1 = format_column_names(df1)
        # print(df1.columns)
        # ----[Agent Name None]--BD
        if 'AgentName' not in df1.columns:
            df1['AgentName'] = None
        df1['AgentName'] = df1.apply(
            lambda row: 'Within Hours' if row['Client_Name'] == 'Bank of America' else 'Filter Out',
            axis=1)
        # ----IST COUNT---CV
        call_counts = df1.groupby('CALLID').size().reset_index(name='Cou')
        df1['ISTCOUNT'] = df1['CALLID'].map(call_counts.set_index('CALLID')['Cou']).fillna(0)
        # ----IST Qwt---CV
        print(df1['QUEUEWAITTIME'])
        df1['ISTQWT'] = df1.apply(lambda row: datetime.strptime(row['QUEUEWAITTIME'], '%H:%M:%S.%f').time() if row[
                                                                                                              'QUEUEWAITTIME'] is not None else None,
                                axis=1)
        df1['ISTQWT'] = df1['ISTQWT'].astype(str).map(lambda x: x.encode('utf-8') if x is not None else None)
        # ---CQ= [ADV Date]
        df1['ADVDate'] = '1900-01-01'
        # ----CY--Count Call ID--
        b = df1.groupby('CALLID')['CALLID'].count().reset_index(name='Cou')
        df1 = df1.merge(b, on='CALLID', how='inner')
        df1['CountCallID'] = df1['Cou']
        df1 = df1.drop('Cou', axis=1)
        #  ---CountIF QCB Added  CZ
        b_temp = df1[df1['CALLTYPE'] == 'QueueCallback'].groupby('CALLID')['CALLID'].count().reset_index(name='Cou')
        df1 = df1.merge(b_temp, on='CALLID', how='left')
        df1['CountIFQCBAdded'] = df1.apply(lambda row: row['Cou'] if row['CountCallID'] > 1 else 0, axis=1)
        df1 = df1.drop('Cou', axis=1)
        # Set QCB Registered All

        # df1 = update_qcb_registered(df1)
        # Set QCB Registered All
        df1['QCBRegisteredAll'] = df1.apply(
            lambda x: 1 if x['CountIFQCBAdded'] == 1 and x['CALLTYPE'] == 'Inbound' and x[
                'QUEUECALLBACKREGISTERED'] == 0 else 0, axis=1)
        df1['QUEUECALLBACKWAITTIME'] = df1['QUEUECALLBACKWAITTIME'].astype(str)

        # Set QCB Registered
        def set_qcb_registered(row):
            if row['QCBRegisteredAll'] == 1:
                return 1
            else:
                if row['DISPOSITION'] == 'Duplicated Callback Request':
                    return 0
                else:
                    if row['QUEUECALLBACKWAITTIME'] > '00:00:00' or row['QUEUECALLBACKREGISTERED'] > 0 or row[
                        'QCB - Registered System'] > 0:
                        return 1
                    else:
                        return 0
        df1['QCBRegistered'] = df1.apply(set_qcb_registered, axis=1)
        #  ---CK  Count QCB Same Date
        # df1 = update_count_qcb_same_date(df1)
        # Perform the join and aggregation
        b = df1.groupby('DATE')['CALLID'].count().reset_index(name='Cou')
        df1 = pd.merge(df1, b, on='DATE', how='inner')

        # Update the Order_Count column
        df1['Order_Count'] = df1['Cou']
        df1_copy = df1.copy()

        # Apply the SQL logic to update the copy of the DataFrame
        df1_copy['CountQCBSameDate'] = df1_copy.apply(
            lambda row: 2 if pd.Timestamp(row['ADVDate']) > pd.Timestamp('1900-01-01') and row['ADVDate'] == row[
                'DATE'] and row['QCBRegistered'] > 0 else (row['Order_Count'] if row['QCBRegistered'] > 0 else 0),
            axis=1
        )
        df1 = df1_copy
        # --CB=Actual Handle Time
        df1['ActualHandleTime'] = df1.apply(
            lambda x: '00:00:00' if x['CALLTYPE'] == 'Inbound' and x['CountQCBSameDate'] >= 2 and x[
                'QCBRegistered'] == 1 else x['HANDLETIME'], axis=1)

        df1['QUEUEWAITTIME'] = df1['QUEUEWAITTIME'].apply(str_to_time)
        df1['QUEUEWAITTIME'] = df1['QUEUEWAITTIME'].astype(str).map(
            lambda x: x.encode('utf-8') if x is not None else None)

        df1['ActualQueueWaitTime'] = df1.apply(lambda row:
                                             '00:00:00' if row['DISPOSITION'] == 'QueueCallbackTimeout' and row[
                                                 'ISTCOUNT'] == 0
                                             else row['ISTQWT'] if row['ISTCOUNT'] > 0 and row['ISTQWT'] < row[
                                                 'QUEUEWAITTIME']
                                             else '00:00:00' if row['CALLTYPE'] == 'Inbound' and row[
                                                 'CountQCBSameDate'] >= 2 and row['QCBRegistered'] == 1
                                             else '00:00:00' if row['CALLTYPE'] == 'QueueCallback' and row[
                                                 'CountQCBSameDate'] >= 2 and row['QCBRegistered'] == 0
                                             else row['QUEUEWAITTIME'], axis=1)
        #df1['ActualQueueWaitTime'] = df1['ActualQueueWaitTime'].apply(str_to_time)
        #df1['ActualHandleTime'] = df1['ActualHandleTime'].apply(str_to_time)

        # --BE=Queue<300
        df1['Queue<300'] = df1.apply(
            lambda x: 1 if int(x['CALLID']) > 1 and str(x['ActualQueueWaitTime']) <= '00:00:01' else 0, axis=1)
        # ----BH=Queue<Goal
        df1['Queue<Goal'] = df1.apply(
            lambda x: 1 if x['Custom_Program'] == 'Basic' and str(x['ActualQueueWaitTime']) <= '00:00:30' else (
                1 if x['Custom_Program'] == 'Premium' and str(x['ActualQueueWaitTime']) <= '00:00:20' else (
                    1 if x['Custom_Program'] == '' and str(x['ActualQueueWaitTime']) <= '00:00:30' else 0)), axis=1)
        # --BS Good Call
        df1['GoodCall'] = df1.apply(lambda x: 'No' if x['AgentName'] == 'Filter Out' else (
            'No' if x['QCBRegistered'] == 1 else ('No' if x['DISPOSITION'] == 'Duplicated Callback Request' else (
                'No' if str(x['ActualHandleTime']) == '00:00:00' and x['Queue<Goal'] == 1 else (
                    'NO' if str(x['ActualHandleTime']) == '00:00:00' and x['Queue<Goal'] == 0 and x[
                        'QCBRegistered'] == 1 else 'Yes')))), axis=1)
        # ----BT=Good Call Offered
        df1['GoodCallOffered'] = df1.apply(
            lambda x: 0 if x['Client_Name'] == '0' else (1 if x['GoodCall'] == 'Yes' else 0), axis=1)
        # ----BU--Handled Formula
        df1['Handledf1ormula'] = df1.apply(lambda x: 0 if x['Client_Name'] == '0' else (
            1 if pd.notnull(x['ActualHandleTime']) and str(x['ActualHandleTime']) > '00:00:00' and x[
                'GoodCallOffered'] == 1 else 0), axis=1)
        # --BQ Abandoned Formula
        df1['Abandonedf1ormula'] = df1.apply(lambda row: 0 if row['Client_Name'] == '0' else (
            1 if str(row['ActualHandleTime']) == '00:00:00' and row['Queue<Goal'] == 0 and row[
                'GoodCallOffered'] == 1 else 0), axis=1)
        # ----CC-Good Call Handle Time
        df1['GoodCallHandleTime'] = df1.apply(lambda row: '' if (row['CALLTYPE'] == 'Inbound' and row[
            'HANDLETIME'] == '00:00:00' and row['Queue<Goal'] == 1) or (row['QCBRegistered'] == 1 and row[
            'HANDLETIME'] == '00:00:00') or (row['CALLTYPE'] == 'Queue Callback' and row[
            'HANDLETIME'] == '00:00:00') or (row['CALLTYPE'] == 'Inbound' and row[
            'DISPOSITION'] == 'Duplicated Callback Request') or row['Abandonedf1ormula'] == 1 else row[
            'ActualHandleTime'], axis=1)
        # ----CE QCB Connects
        df1['QCBConnects'] = df1.apply(
            lambda row: 1 if row['CALLTYPE'] == 'Queue Callback' and type(row['ActualHandleTime']) == datetime.time and
                             row['ActualHandleTime'].strftime('%H:%M:%S') > '00:00:00' else 0, axis=1)
        # --CD QCB Wait Time
        if 'SUM_QUEUECALLBACKWAITTIME' not in df1.columns:
            df1['SUM_QUEUECALLBACKWAITTIME'] = '00:00:00'
        df1['QCBWaitTime'] = df1.apply(lambda row: '' if (
                row['CALLTYPE'] == 'Inbound' and row['GoodCallHandleTime'] == '00:00:00' and row[
            'QCBRegistered'] == 0) else
        ('' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] >= 2 and row['QCBRegistered'] == 1) else
         ('' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] >= 1 and row['QCBRegistered'] == 1) else
          ('00:00:00' if (row['CALLTYPE'] == 'Queue Callback' and row['CountQCBSameDate'] >= 2 and row[
              'QCBRegistered'] == 0) else row.get('SUM_QUEUECALLBACKWAITTIME', '00:00:00')))),
                                     axis=1)
        # --CM Index ANI DNIS
        df1['IndexANIDNIS'] = 0
        # ----CI Duplicate Requests Count
        df1['DuplicateRequestsCount'] = df1.apply(
            lambda row: 3 if row['IndexANIDNIS'] > 0 and row['IndexANIDNIS'] != row['CALLID'] else (
                row['Order_Count'] if row['QCBRegistered'] > 0 else 0), axis=1)
        df1['DuplicateRequestsCount'] = df1.apply(
            lambda row: 1 if row['DISPOSITION'] == 'Duplicated Callback Request' else 0, axis=1)
        # ----BR Short Abandons
        df1['ShortAbandons'] = df1.apply(lambda row: 1 if row['DuplicateRequestsCount'] == 1 else
        (1 if (row['Queue<Goal'] == 1 and row['ActualHandleTime'] == '00:00:00') else
         (0 if (row['Queue<Goal'] == 0 and row['ActualHandleTime'] == '00:00:00') else
          (1 if (row['QCBRegistered'] == 1 or row['Handledf1ormula'] == 0) else 0))),
                                       axis=1)
        # --BW IVR Calls
        df1['IVRCalls'] = df1.apply(lambda row: 1 if int(row['CALLID']) > 1 else 0, axis=1)
        # ----BN QCB Offered
        df1['QCBOffered'] = df1.apply(lambda row: 1 if str(row['QUEUEWAITTIME']) > '00:00:03' or row[
            'Custom_QueueCallback_Offered'] == 1 else 0, axis=1)
        # --CF Custom Campaign Formula--
        df1['CustomCampaignFormula'] = df1.apply(
            lambda row: 'Expedia Migration' if row['CAMPAIGN'] == 'Bank of America - Expedia Inbound Transfer' or row[
                'CAMPAIGN'] == 'Bank of America - ML - Expedia Inbound Transfer' else row['Client_CustomClient'],
            axis=1)
        # --SUMifs EWT
        df1_merged = df1[df1['Custom_EWT'] > 0].groupby(['DATE', 'HOUR', 'CustomCampaignFormula']).size().reset_index(
            name='Count')
        df1_merged.rename(columns={'Count': 'CountifsEWT'}, inplace=True)
        df1 = pd.merge(df1, df1_merged, on=['DATE', 'HOUR', 'CustomCampaignFormula'], how='left')
        df1['CountifsEWT'].fillna(0, inplace=True)
        df1_sum = df1[df1['Custom_EWT'] > 0].groupby(['DATE', 'HOUR', 'CustomCampaignFormula'])[
            'Custom_EWT'].sum().reset_index(name='Count')
        df1_sum['Count'] = df1_sum['Count'].astype(int)
        df1_sum.rename(columns={'Count': 'SumifsEWT'}, inplace=True)
        df1 = pd.merge(df1, df1_sum, on=['DATE', 'HOUR', 'CustomCampaignFormula'], how='left')
        df1['SumifsEWT'].fillna(0, inplace=True)
        # ----AVGifs EWT
        df1_filtered = df1[(df1['Custom_EWT'] != '') & (df1['Custom_EWT'] != '10')]
        df1_filtered['Custom_EWT'] = df1_filtered['Custom_EWT'].astype(float)
        df1_merged = df1_filtered.groupby(['DATE', 'HOUR', 'CustomCampaignFormula'])[
            'Custom_EWT'].mean().round().reset_index(name='Cou')
        df1_merged.rename(columns={'Cou': 'AVgifsEWT'}, inplace=True)
        df1 = pd.merge(df1, df1_merged, on=['DATE', 'HOUR', 'CustomCampaignFormula'], how='left')
        df1['AVgifsEWT'].fillna(0, inplace=True)
        # -- --CU AVE EWT Quote
        df1['AVEEWTQuote'] = df1.apply(lambda row: 0 if row['Custom_EWT'] == 0 else (
            row.get('SumifsEWT', 0) if row['CountifsEWT'] == 1 else (
                row.get('AvgifsEWT', 0) if row['Custom_EWT'] == 10 else row['Custom_EWT'])), axis=1)
        # --BM-EWT Quoted -(Time)
        df1['EWTQuoted_Time'] = df1.apply(lambda row: '' if row['Handledf1ormula'] == 0 else (
            '' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] == 0 and row[
                'QCBRegistered'] == 0) else (
                '' if (row['CALLTYPE'] == 'Inbound' and row['CountQCBSameDate'] == 2 and row[
                    'QCBRegistered'] == 1) else ('' if (
                        row['CALLTYPE'] == 'Queue Callback' and row['CountQCBSameDate'] == 2 and row[
                    'QCBRegistered'] == 0) else convert_to_time(float(row['AVEEWTQuote']) * 60)))), axis=1)
        # --BG-Queue Time
        df1['ActualQueueWaitTime'] = df1['ActualQueueWaitTime'].str.decode('utf-8')  # Convert bytes to string
        df1['ActualQueueWaitTime'] = pd.to_datetime(df1['ActualQueueWaitTime'])  # Convert string to datetime
        df1['QueueTime'] = df1.apply(
            lambda row: (row['ActualQueueWaitTime'].hour * 60) + row['ActualQueueWaitTime'].minute + (
                        row['ActualQueueWaitTime'].second / 60),
            axis=1)
        # --CH Queue > 10
        df1['Queue>10'] = df1['QueueTime'].apply(lambda x: 1 if x > 10 else 0)
        # --CL QCB Same Day Connects
        df1['QCBSameDayConnects'] = df1['CountQCBSameDate'].apply(lambda x: 1 if x == 2 else 0)
        # --[QCB Attempts]
        df1['QCBAttempts'] = df1['CALLTYPE'].apply(lambda x: 1 if x == 'QueueCallback' else 0)

    except Exception as e:
        traceback.print_exc()
        print(f"An error occurred: {str(e)}")
    return df1

def str_to_time(x):
    if not isinstance(x, str):
        return x
    if x == 'nan':
        x = '00:00:00.000'
    return datetime.strptime(x, '%H:%M:%S.%f').time()

def convert_to_time(minutes):
    time = timedelta(minutes=minutes)
    return (datetime.min + time).time().strftime('%H:%M:%S')


#Final Five9 STEP - 4

def load_five9_final_data_all_from_gcs_to_bq(five9_after, short_report_name):

  project_id = "bkt-nonprod-dev-dwh-svc-00"
  print(project_id)

  bq_client = bigquery.Client(project = project_id)

  data_aset_name = "bq_dataset_five9"
  print(data_aset_name)

  tbl_name = str(data_aset_name) + ".bq_five9_" + short_report_name +"_final_tbl"
  print(tbl_name)
  dataset = bq_client.create_dataset(data_aset_name, exists_ok=True)

  if short_report_name == 'bacqcb': #bacqcb
    print("Creating final tables for "+short_report_name)
    five9_after_final = update_bac_qcb_program_level(five9_after)
  else:
    print("Missing short_report_name : "+short_report_name)

  #five9_after_final = five9_after
  #five9_after_final = convert_datetime_to_bytes(five9_after_final)
  five9_after_final.head(3)
  five9_after_final.to_gbq(
      destination_table=tbl_name,
      project_id = project_id,
      if_exists="replace",  # 3 available methods: fail/replace/append
  )

  # Load into SQL Server
  return five9_after_final

# STEP - 5

def hello_http(request):
  df = fetch_report(24,60,'Shared Reports', 'BAC - Call Data Daily (BAC QCB) v4.18.21','bacqcb')
  df.head(3)

  df1 = load_five9_data_all_from_gcs_to_bq('bacqcb')
  df1.head(3)

  five9_after_final = load_five9_final_data_all_from_gcs_to_bq(df, 'bacqcb')
  five9_after_final.head(3)
  
  return {'response' : 'Success'}
