import os
from google.cloud import bigquery
from google.cloud import storage
import datetime

def load_csv_to_bq(bucket_name, file_name):
    # Check if the uploaded file is a CSV
    if not file_name.lower().endswith('.csv'):
        print(f"Skipping non-CSV file: {file_name}")
        return
    
    # Set BigQuery configurations
    project_id = "bkt-nonprod-dev-dwh-svc-00"
    dataset_id = "bq_dataset_five9"
    table_id = "bq_five9_bacqcb_tbl"
    
    # Initialize BigQuery and Storage clients
    bq_client = bigquery.Client(project=project_id)
    storage_client = storage.Client(project=project_id)
    
    # Define the Cloud Storage file URI
    file_uri = f"gs://{bucket_name}/{file_name}"
    
    # Define BigQuery table reference
    table_ref = bq_client.dataset(dataset_id).table(table_id)
    
    # Load the CSV file into BigQuery
    job_config = bigquery.LoadJobConfig(
        schema=[
			bigquery.SchemaField("Unnamed:0","INT64"),
			bigquery.SchemaField("CALLID","INT64"),
			bigquery.SchemaField("SESSIONID","STRING"),
			bigquery.SchemaField("YEAR","INT64"),
			bigquery.SchemaField("MONTH","STRING"),
			bigquery.SchemaField("DATE","STRING"),
			bigquery.SchemaField("DAYOFMONTH","INT64"),
			bigquery.SchemaField("DAYOFWEEK","STRING"),
			bigquery.SchemaField("DATEANDHOUR","STRING"),
			bigquery.SchemaField("HOUR","STRING"),
			bigquery.SchemaField("HOUROFDAY","INT64"),
			bigquery.SchemaField("HALFHOUR","STRING"),
			bigquery.SchemaField("QUARTERHOUR","STRING"),
			bigquery.SchemaField("TIME","STRING"),
			bigquery.SchemaField("Client_Name","STRING"),
			bigquery.SchemaField("Client_CustomClient","STRING"),
			bigquery.SchemaField("CAMPAIGN","STRING"),
			bigquery.SchemaField("Custom_CustomerType","STRING"),
			bigquery.SchemaField("SKILL","STRING"),
			bigquery.SchemaField("DISPOSITION","STRING"),
			bigquery.SchemaField("CALLTYPE","STRING"),
			bigquery.SchemaField("CAMPAIGNTYPE","STRING"),
			bigquery.SchemaField("Custom_Interest","STRING"),
			bigquery.SchemaField("CALLS","INT64"),
			bigquery.SchemaField("CONTACTED","INT64"),
			bigquery.SchemaField("LIVECONNECT","FLOAT64"),
			bigquery.SchemaField("ABANDONED","FLOAT64"),
			bigquery.SchemaField("TRANSFERS","FLOAT64"),
			bigquery.SchemaField("HOLDS","FLOAT64"),
			bigquery.SchemaField("PARKS","FLOAT64"),
			bigquery.SchemaField("CALLTIME","STRING"),
			bigquery.SchemaField("BILLTIME_ROUNDED_","STRING"),
			bigquery.SchemaField("IVRTIME","STRING"),
			bigquery.SchemaField("QUEUEWAITTIME","STRING"),
			bigquery.SchemaField("RINGTIME","STRING"),
			bigquery.SchemaField("TALKTIME","STRING"),
			bigquery.SchemaField("HOLDTIME","STRING"),
			bigquery.SchemaField("AFTERCALLWORKTIME","STRING"),
			bigquery.SchemaField("SPEEDOFANSWER","STRING"),
			bigquery.SchemaField("DIALTIME","FLOAT64"),
			bigquery.SchemaField("TALKTIMELESSHOLDANDPARK","STRING"),
			bigquery.SchemaField("HANDLETIME","STRING"),
			bigquery.SchemaField("MANUALTIME","FLOAT64"),
			bigquery.SchemaField("TIMETOABANDON","STRING"),
			bigquery.SchemaField("QUEUECALLBACKWAITTIME","STRING"),
			bigquery.SchemaField("ANI","STRING"),
			bigquery.SchemaField("DNIS","INT64"),
			bigquery.SchemaField("Custom_IVRCancellations","FLOAT64"),
			bigquery.SchemaField("Custom_Language","STRING"),
			bigquery.SchemaField("Custom_Program","STRING"),
			bigquery.SchemaField("Custom_QueueCallback_Offered","FLOAT64"),
			bigquery.SchemaField("Custom_QueueCallback_Requested","FLOAT64"),
			bigquery.SchemaField("QUEUECALLBACKREGISTERED","INT64"),
			bigquery.SchemaField("Custom_QueueCallBack_Registered","FLOAT64"),
			bigquery.SchemaField("Custom_EWT","FLOAT64"),
			bigquery.SchemaField("Custom_SelfService","FLOAT64")
            # Add more schema fields as needed
        ],
        skip_leading_rows=1,
        source_format=bigquery.SourceFormat.CSV,
        write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
    )
    
    load_job = bq_client.load_table_from_uri(
        file_uri, table_ref, job_config=job_config
    )
    
    load_job.result()  # Wait for the job to complete
    
    print(f"CSV file {file_uri} loaded into BigQuery table {table_id}")

def hello_http(request):
    data = request.get_json()
    if data and 'bucket' in data and 'name' in data:
        bucket_name = data['bucket']
        file_name = data['name']
        
        # Get the current date in the format YYYY-MM-DD
        current_date = datetime.datetime.now().strftime('%Y-%m-%d')
        
        # Check if the file name contains the current date and 'bcaqcb'
        if current_date in file_name and 'bcaqcb' in file_name and file_name.lower().endswith('.csv'):
            load_csv_to_bq(bucket_name, file_name)
            return "CSV loading process initiated."
        else:
            return "File name does not match the pattern or is not a CSV file."
    else:
        return "Invalid request data."
