#Final
from google.cloud import bigquery
from google.cloud import storage
import os
import pandas as pd
from datetime import datetime, timedelta
# import pyodbc
import sqlalchemy

def load_jira_project_statuses_data_all_from_gcs_to_SQL():

  print('function execution started')
  current_datetime = datetime.now()
  current_date_time = current_datetime.strftime("%m-%d-%Y")
  print("current date and time = ",current_date_time)

  print('executed as User:   ', os.getenv("USERNAME"))

  print("\n\n")

  project_id = "bkt-nonprod-dev-dwh-svc-00"
  dataset_id = "bq_dataset_jira_statuses"
  table_id = "bq_jira_statuses_tbl"

  bq_client = bigquery.Client(project = project_id)

  # job_config = bigquery.QueryJobConfig()
  query = "SELECT * FROM `{}.{}.{}`".format(project_id,dataset_id, table_id)
  print(query)

  """
  query_job = bq_client.query(query)  # API request
  rows = query_job.result()  # Waits for query to finish
  type(rows)
  # for row in rows:
  #     print(row.key)
  """

  df = bq_client.query(query).to_dataframe()
  df.head(3) 
  df1 = df.head(3)
  print('function execution completed')

  

  return df1

def hello_http(request):
  df = load_jira_project_statuses_data_all_from_gcs_to_SQL()
  df.head(3) 
  
  print('create_engine called')
  sql_server = sqlalchemy.create_engine('mssql+pyodbc://' + 'LTYPTRDWSISQL1' + '/' + 'DBA' + '?trusted_connection=yes&driver=SQL+Server',use_setinputsizes=False)

  print('writing into sql started', datetime.now())
  df.to_sql('Jira_history2', sql_server, if_exists = 'replace')
  print('writing into sql finished', datetime.now())
  return {'response' : 'Success'}



