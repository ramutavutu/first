# Google Datastream

### This code sets up a datastream pipeline to stream data from a MySQL source to a Google Cloud Storage (GCS) destination. 
* **It does this by creating a connection profile for both the MySQL source and the GCS destination, assigning IAM roles to the datastream service account, and then creating a stream that maps the source to the destination.**
* **The code includes variable inputs for project id, display names, region, bucket names, storage class, and IAM member roles.**
* **There are also dynamic variables for included MySQL databases and tables that allow for flexible mapping of tables to the destination.** 
* **Finally, there are dependencies specified between resources to ensure that the pipeline is created in the correct order.**

## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_datastream_connection_profile.destination_connection_profile](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/datastream_connection_profile) | resource |
| [google_datastream_connection_profile.source_connection_profile](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/datastream_connection_profile) | resource |
| [google_datastream_stream.gcs_dwh](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/datastream_stream) | resource |
| [google_storage_bucket.dest_bucket](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket) | resource |
| [google_storage_bucket_iam_member.gcs_roles](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket_iam_member) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_db_password"></a> [db\_password](#input\_db\_password) | DB Password | `string` | n/a | yes |
| <a name="input_desired_state"></a> [desired\_state](#input\_desired\_state) | The desired state of the resource. | `string` | n/a | yes |
| <a name="input_destination_config"></a> [destination\_config](#input\_destination\_config) | Destination Config | <pre>object({<br>        gcs_destination_config= optional(object({<br>            file_rotation_mb = number<br>            file_rotation_interval = string<br>            file_type = string<br>        }))<br>        bigquery_destination_config = optional(object({<br>            data_freshness = string<br>        }))<br>    })</pre> | n/a | yes |
| <a name="input_destination_connection"></a> [destination\_connection](#input\_destination\_connection) | Destination Connection | <pre>object({<br>        type = string<br>        display_name = string<br>        connection_profile_id = string<br><br>        gcs_profile = optional(object({<br>            bucket = string<br>            storage_class = string<br>        }))   <br><br>    })</pre> | n/a | yes |
| <a name="input_display_name"></a> [display\_name](#input\_display\_name) | The display name for a resource. | `string` | n/a | yes |
| <a name="input_labels"></a> [labels](#input\_labels) | A map of key-value pairs to label the resource. | `map(string)` | n/a | yes |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | Project ID | `string` | n/a | yes |
| <a name="input_project_id_sec"></a> [project\_id\_sec](#input\_project\_id\_sec) | Secretes project id | `string` | n/a | yes |
| <a name="input_project_number"></a> [project\_number](#input\_project\_number) | Project Number | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | Region | `string` | n/a | yes |
| <a name="input_source_config"></a> [source\_config](#input\_source\_config) | Source config | <pre>object({<br>        include_objects = object({<br>            mysql_databases = optional(list(object({<br>                database = string<br>                mysql_tables = optional(list(string))<br>            })))<br>            postgresql_schema = optional(list(object({<br>                schema = string<br>                postgresql_tables = optional(list(string))<br>            })))<br>        })<br>        postgres_replication_slot = optional(string)<br>        postgres_publication = optional(string)<br>    })</pre> | n/a | yes |
| <a name="input_source_connection"></a> [source\_connection](#input\_source\_connection) | Source connection | <pre>object({<br>        type= string<br>        display_name = string<br>        connection_profile_id = string<br>        db_password = string<br>        mysql_profile = optional(object({<br>            hostname = string<br>            username = string<br>            <br>        }))<br>        postgres_profile = optional(object({<br>            hostname = string<br>            username = string<br>            database = string<br>        }))<br><br>    })</pre> | n/a | yes |
| <a name="input_stream_id"></a> [stream\_id](#input\_stream\_id) | The ID of the stream. | `string` | n/a | yes |

## Outputs

No outputs.
